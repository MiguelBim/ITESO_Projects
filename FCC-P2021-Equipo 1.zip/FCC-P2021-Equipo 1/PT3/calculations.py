from validator import isNotOperator
from Proposition import proposition_generator


# This function will do all the logic calculation of the premises
# It searches for operands and creates a new key from the result of the operation
# each done operation is wiped from the premise string and replaced with the new key
# gets a dictionary where propositions will be the keys and its values will be the truth values

def logicCalculation(premise, propositionsDict):
    propositions = dict(propositionsDict)
    newKey = premise

    # region Check for not calculations

    for index in range(len(premise)):

        if '~' in premise:

            dictKey = premise[index]

            if dictKey in propositions and isNotOperator(premise[index - 1]):
                value = not propositions[dictKey]
                newKey = proposition_generator(propositions, value)
                premise = premise[: index - 1] + newKey + premise[index + 1:]

    # endregion

    # region Check for and calculations

    for index in range(0, len(premise) - 1):

        if '&' in premise:

            if premise[index] == '&':
                leftProposition = premise[index - 1]
                rightProposition = premise[index + 1]

                value = propositions[leftProposition] and propositions[rightProposition]
                newKey = proposition_generator(propositions, value)
                premise = premise[: index - 1] + newKey + premise[index + 2:]

    # endregion

    # region Check for or calculations

    for index in range(0, len(premise) - 1):

        if premise[index] == 'v':
            leftProposition = premise[index - 1]
            rightProposition = premise[index + 1]

            value = propositions[leftProposition] or propositions[rightProposition]
            newKey = proposition_generator(propositions, value)
            premise = premise[: index - 1] + newKey + premise[index + 1:]

    # endregion

    # region Check for conditional calculations

    for index in range(0, len(premise) - 1):

        if '<->' in premise:

            if premise[index - 1] == '<' and premise[index] == '-':
                leftProposition = premise[index - 2]
                rightProposition = premise[index + 2]

                value = biconditionalCalculation(propositions[leftProposition], propositions[rightProposition])
                newKey = proposition_generator(propositions, value)
                premise = premise[: index - 2] + newKey + premise[index + 2:]

        elif '->' in premise:

            if premise[index - 1] == '-' and premise[index] == '>':
                leftProposition = premise[index - 2]
                rightProposition = premise[index + 1]

                value = conditionalCalculation(propositions[leftProposition], propositions[rightProposition])
                newKey = proposition_generator(propositions, value)
                premise = premise[: index - 2] + newKey + premise[index + 2:]

    return propositions[newKey]

# Conditional calculation funciton, gets booleans and returns result of calculation
def conditionalCalculation(p, q):
    return not p or q

# Biconditional calculation funciton, gets booleans and returns result of calculation
def biconditionalCalculation(p, q):
    return ((not p) or q) and ((not q) or p)