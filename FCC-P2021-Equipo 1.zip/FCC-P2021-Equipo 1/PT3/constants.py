# List of valid propositions, propositions are represented as lowercase
proposition_list = ['p','q','r','s,','t','u','v','w','x','y','z']
# List of keys to represent logic operations
operation_key = ['P','Q','R','S','T','U','V','W','X','Y','Z']