from validator import isValidProposition
from validator import isNotOperator
from constants import operation_key

# Class to define propositions
class Proposition:

    def __init__(self, letter, isNegated):
        self.letter = letter
        self.isNegated = isNegated

# This function will create premises into propositions
def proposition_parser(premise):
    proposition_list = []
    premise = premise.replace(" ", "")
    premise = premise.lower()

    for index in range(0, len(premise)):

        newProposition = Proposition('', False)

        if isValidProposition(premise[index]):

            if premise[index] not in proposition_list:
                newProposition.letter = premise[index]
                newProposition.isNegated = isNotOperator(premise[index - 1])
                proposition_list.append(newProposition)

    if len(proposition_list) > 0:
        return proposition_list
    else:
        return None

# Creates a new key with its value and modifys current calculation dictionary
def proposition_generator(propositionsDictionary, value):
    for newKey in operation_key:

        if newKey in propositionsDictionary:
            continue

        else:

            propositionsDictionary[newKey] = value
            break

    return newKey