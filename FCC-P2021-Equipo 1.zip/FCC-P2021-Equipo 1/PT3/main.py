# Function and parsers Imports
from Proposition import proposition_parser
from calculations import logicCalculation

# Premises l¡ist given by user      [ "p->qVr", "q->p&r" ]
premise_list = []
# Parsed propositions list          [ "p", "q", "r" ]
proposition_list = []
# Parsed propositions object list   [ {"letter":"p","isNegated":"false"}, {},{} ]
propositionObject_list = []
# Table's header                    [ "p", "q", "r","p->qVr", "q->p&r" ]
table_header = []


def pedirPremisa():
    # Variable para controlar cantidad de premisas a leer
    it = 0
    requestEnd = False

    print("\nBienvenido al validador de Argumentos, la última premisa ingresada será considerada conclusión "
          "\n & -> And "
          "\n v = Or"
          "\n ~ = Not "
          "\n -> = Condicional "
          "\n <-> = Bicondicional "
          "\nNo utilices otros símbolos\n")

    while not requestEnd:

        premise = None
        # Guardamos la premisa ingresada por el usuario
        premise = input("\nIngresa la premisa {}: ".format(it + 1))
        propositions = proposition_parser(premise)

        while propositions is None:
            print("Debes ingresar una froma válida \n")
            premise = input("\nIngresa la premisa {}: ".format(it + 1))
            # Parseamos la premisa para que nos regrese las proposiciones
            propositions = proposition_parser(premise)

        premise_list.append(premise)

        for item in propositions:

            if item.letter not in proposition_list:
                proposition_list.append(item.letter)
                propositionObject_list.append(item)

        op = input("\n\n¿Deseas continuar ingresando premisas? [Y,N]").upper()

        if op == 'N':
            requestEnd = True

        it += 1


def tableHeaderHandler():
    for proposition in proposition_list:
        table_header.append(proposition)

    for propositionObject in propositionObject_list:
        if propositionObject.isNegated:
            table_header.append("~" + str(propositionObject.letter))

    for premise in premise_list:
        # if premise not in table_header:
        table_header.append(premise)

    print()
    for column in table_header:
        print("  " + column + "  ", end=" ")
    print()


def setCounterObject():
    propositionObject = {}
    proposition_listHandler = proposition_list[::-1]

    for proposition in range(0, len(proposition_list)):
        counterObject = dict
        counterObject = {"start": 0, "end": (2 ** (proposition + 1)) / 2, "value": True}
        dictKey = proposition_listHandler[proposition]
        propositionObject[dictKey] = counterObject

    return propositionObject


def printTruthTable():
    tableHeaderHandler()
    counterObject = setCounterObject()
    isValidArgument = True  # Argument validation Variable

    # Rows length = 2 raised to propositions length (p,q,r...)
    for row in range(0, (2 ** len(proposition_list))):

        propositionValues = {}  # Object to store current prop values
        argumentValues = []  # List to store critical rows values

        for proposition in proposition_list:

            # Counter will help to print ordered truth values
            counter = counterObject[proposition]

            # If start reaches end, a group of truth values were printed
            if counter["start"] == counter["end"]:
                # Reset counter and reverse truth value to print other group of values
                counter["start"] = 0
                counter["value"] = not counter["value"]

            if counter["start"] < counter["end"]:

                end = '  '
                if counter["value"] is True:
                    end = '   '

                print(counter["value"], end=end)
                # propositionValues will store current truth values using proposition letter as a key
                propositionValues[proposition] = counter["value"]
                counter["start"] = counter["start"] + 1

        # This for will print propositions and premises that need to be calculated
        tableHeader_handler = table_header[len(proposition_list):]
        for header in tableHeader_handler:

            # Premise result will store premise result, premise is sent as header
            premiseResult = logicCalculation(header, propositionValues)
            # This list will help to determine if a row is critic or not
            argumentValues.append(premiseResult)

            end = '  '
            if premiseResult is True:
                end = '   '

            # Prints premise calculation result
            print(premiseResult, end=end)

        isCriticRow = True

        # If all values are true, then it is a critic row
        for value in argumentValues[:len(argumentValues) - 1]:
            if value is False:
                isCriticRow = False

        conclusionValue = False
        if len(argumentValues) > 1:
            # Last premise calculation result
            conclusionValue = argumentValues[len(argumentValues) - 1:len(argumentValues)][0]
        # if true, it means that there is a critic row where its conclusion is false
        if isCriticRow and (not conclusionValue):
            isValidArgument = False

        print()

    if isValidArgument:
        print("\n---- Es un argumento válido ----")
    else:
        print("\n---- No es un argumento válido ----")


pedirPremisa()
printTruthTable()