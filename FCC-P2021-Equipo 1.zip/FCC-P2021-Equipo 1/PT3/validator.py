from constants import proposition_list

# Function to check if a char in a premise is valid
def isValidProposition(char):
    if char == '¬' or char == '~':
        return False

    if char == 'v':
        return False

    if char == '&':
        return False

    if '-' == char or '<' == char or '>' == char:
        return False

    if ' ' == char:
        return False

    if char == '(' or char == ')':
        return False

    if char in proposition_list:
        return True

    return False

# Function to check if a proposition is negated
def isNotOperator(char):
    if char == '¬' or char == '~':

        return True

    else:

        return False