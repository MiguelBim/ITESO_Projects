# Letras para asignar como literal de cada premisa
diccionarioLetras = ['p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y']