# Importamos las funciones de cada archivo
from Premisa import premisaParser
# from operacionesLogicas import operacion
from operacionesLogicas import andLogico
from operacionesLogicas import orLogico
from operacionesLogicas import condicionalLogico

# Lista que contendrá las premisas ingresadas por el usuairo (p->qv¬r,...)
listaPremisas = []
# Lista de proposiciones (p,q,r..)
proposiciones = []
# Lista de objetos de tipo Premisa
objetoProposiciones = []


# Función para leer premisas y convertirlas a objetos tangibles
def pedirPremisa():

    # Variable para controlar cantidad de premisas a leer
    it = 0
    finSolicitud = False

    print("\nBienvenido al validador de Argumentos, debes ingresar el argumento de ejemplo donde "
          "\nP1= p->qv¬r, "
          "\nP2= p->q&r, "
          "\nC = p->r"
          "\nNo utilices otros símbolos\n")

    while not finSolicitud:

        premisa = None
        mensaje = "\nIngresa la premisa {}: ".format(it + 1)

        if it == 2:

            mensaje = "\nIngresa la conclusión: "

        # Guardamos la premisa ingresada por el usuario
        premisa = input(mensaje)
        objetoPremisas = premisaParser(premisa)

        while objetoPremisas is None:

            print("Debes ingresar una froma válida \n")
            premisa = input(mensaje)
            objetoPremisas = premisaParser(premisa)

        listaPremisas.append(premisa)

        for proposicion in objetoPremisas:

            if proposicion.letra in proposiciones:
                continue

            else:

                proposiciones.append(proposicion.letra)
                objetoProposiciones.append(proposicion)

        if it == 2:

            finSolicitud = True
            print()

        it += 1

def imprimirTabla():

    proposicionNegada = []

    for objeto in objetoProposiciones:

        if objeto.negada:

            # En caso de que existan proposiciones negadas, se agregan al arreglo antes de las premisas
            proposiciones.append('~' + objeto.letra)
            proposicionNegada.append('~' + objeto.letra)

    for premisa in listaPremisas:

        # Se agregan las premisas al arreglo que imprime el header de la tabla
        proposiciones.append(premisa)

    # Se imprimen el header de la tabla, contiene las proposiciones, proposiciones negadas y premisas al final
    print()
    for proposicion in proposiciones:
        print("  " + proposicion + "  ", end='  ')
    print("\n")

    # Con este arreglo se controla de forma dinámica la impresión de valores de verdad de cada proposición
    contadorPremisa = []

    for proposicion in range(len(objetoProposiciones), 0, -1):

        # Inicio del contador
        inicio = 0
        # Fin del contador
        fin = (2 ** proposicion) / 2
        # Valor a imprimir
        primerValor = True
        contadorPremisa.append([inicio, fin, primerValor])

    # La cantidad de filas es igual dos, elevado al número de proposiciones (p,q,r...)
    for fila in range(0, (2 ** len(objetoProposiciones))):

        # Arreglo para almacenar los valores de verdad que se utilizaran para las opreaciones logicas
        valorOperaciones = []

        # Este for se ejecuta tres veces
        for premisa in range(0, len(objetoProposiciones)):

            if contadorPremisa[premisa][0] == contadorPremisa[premisa][1]:
                # Ya se imprimió un bloque de valores
                # Se reinicia el contador
                contadorPremisa[premisa][0] = 0
                # Se cambia el valor a imprimir
                contadorPremisa[premisa][2] = not contadorPremisa[premisa][2]

            if contadorPremisa[premisa][0] < contadorPremisa[premisa][1]:

                # Aún no se termina de imprimir el bloque de valores
                end = '  '
                if contadorPremisa[premisa][2] is True:
                    end = '   '

                # Se imprime el valor actual
                print(contadorPremisa[premisa][2], end=end)
                valorOperaciones.append(contadorPremisa[premisa][2])
                # Se incrementa el contador
                contadorPremisa[premisa][0] = contadorPremisa[premisa][0] + 1

        if len(proposicionNegada) > 0:

            end = '       '
            if valorOperaciones[2] is True:
                end = '      '
            print(not valorOperaciones[2], end=end)

        for premisa in range(0, len(listaPremisas)):

            if premisa == 0:

                premisa1 = condicionalLogico(valorOperaciones[0], valorOperaciones[1])
                premisa1 = orLogico(premisa1, not valorOperaciones[2])
                end = '       '
                if premisa1:
                    end = '        '
                print( str(premisa1), end=end)

            elif premisa == 1:

                premisa2 = andLogico(valorOperaciones[0], valorOperaciones[2])
                premisa2 = condicionalLogico(valorOperaciones[1],premisa2)
                end = '       '
                if premisa2:
                    end = '        '
                print(str(premisa2), end=end)

            elif premisa == 2:
                conclusion = condicionalLogico(valorOperaciones[0], valorOperaciones[2])
                end = '       '
                if conclusion:
                    end = '        '
                print(str(conclusion), end=end)

        print()


pedirPremisa()
imprimirTabla()