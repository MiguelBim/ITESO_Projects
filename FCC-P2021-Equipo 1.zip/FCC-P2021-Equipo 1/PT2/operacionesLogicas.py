# Conjunto de funciones para realizar las operaciones lógicas según la selección del usuario

def andLogico(p, q):

    return p and q

def orLogico(p, q):

    return p or q

def condicionalLogico(p, q):

    return not p or q

def bicondicionalLogico(p, q):

    return ((not p) or q) and ((not q) or p)
