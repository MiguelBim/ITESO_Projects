from validaciones import validarProposicion
from constantes import diccionarioLetras

# Clase para construir premisas como objetos
class Premisa:
    def __init__(self, negada, letra):

        self.letra = letra
        self.negada = negada


def premisaParser(premisa):

    proposiciones = []

    for charIndex in range(0, len(premisa)):

        proposicion = Premisa('','')

        if  validarProposicion(premisa[charIndex]):

            if premisa[charIndex] in diccionarioLetras and premisa[charIndex] not in proposiciones:

                if premisa[charIndex - 1] == '¬':
                    proposicion.negada = True
                else:
                    proposicion.negada = False

                proposicion.letra = premisa[charIndex]
                proposiciones.append(proposicion)



    if len(proposiciones) == 0:
        return None
    else:
        return proposiciones