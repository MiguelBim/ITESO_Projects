# Conjunto de funciones para realizar las operaciones lógicas según la selección del usuario

def andLogico(p, q):

    print("\nResultado de la operación: ", p and q)

    return True

def orLogico(p, q):
    
    print("\nResultado de la operación: ", p or q)

    return True

def condicionalLogico(p, q):
    print("\nResultado de la operación: ", not p or q)

    return True

def bicondicionalLogico(p, q):
    
    op = ((not p) or q) and ((not q) or p)

    print("\nResultado de la operación: ", op)

    return True