# Clase para construir premisas como objetos
class Premisa:
    def __init__(self, valor, descripcion, letra):

        self.valor = valor
        self.descripcion = descripcion
        self.letra = letra

    # Método para negar el valor de una premisa 
    def negar(self):

        self.valor = not self.valor

        return True