# Importamos las funciones de cada archivo
from Premisa import Premisa
from validaciones import valoresDeVerdad
from validaciones import validarOperacion
from constantes import diccionarioLetras
from operacionesLogicas import andLogico
from operacionesLogicas import orLogico
from operacionesLogicas import condicionalLogico
from operacionesLogicas import bicondicionalLogico

# Lista que contendrá las premisas ingresadas por el usuairo
objetoPremisas = []

    # Función para solicitar leer premisas y convertirlas a objetos tangibles
def pedirPresmisas():

    # Variable para controlar cantidad de premisas a leer
    it = 0

    while it <= 1:

        # Definición de objeto de tipo Premisa
        premisa = Premisa('', '', '')

        # Asignamos la descripción que ingresa el usuario
        premisa.descripcion = input("Ingresa la premisa {}: ".format(it + 1))
        # Validamos el valor que da el usuario y asignamos un booleano
        premisa.valor = valoresDeVerdad(input("Ingresa el valor de la premisa: "))
        # Asignamos una letra según el índice
        premisa.letra = diccionarioLetras[it]

        # Agregamos cada objeto a la lista de objetos
        objetoPremisas.append(premisa)

        it += 1


# Función para mostrar al usuario las premisas que ha ingresado al momento
def imprimirPremisas(listaObjetos):

    # Imprime cada propiedad de cada objeto en la lista
    for premisa in listaObjetos:
        print("\nDescripción: ", premisa.descripcion)
        print("Letra: ", premisa.letra)
        print("Valor: ", premisa.valor)

    return True

# Función para leer la operación a realizar según las premisas ingresadas
def leerOperacion():

    # Validamos y guardamos la operación a realizar
    operacionRealizar = validarOperacion(input("\nIngresa la operación a realizar entre p y q: "))

    return operacionRealizar


# Función para realizar operación lógica seleccionada por el usuario
def hacerOperacion(operacionRealizar):

    # Guardamos los valores de verdad de cada premisa
    premisa1 = objetoPremisas[0].valor
    premisa2 = objetoPremisas[1].valor

    if operacionRealizar == 'and':
        andLogico(premisa1, premisa2)

    if operacionRealizar == 'or':
        orLogico(premisa1, premisa2)

    if operacionRealizar == 'Condicional':
        condicionalLogico(premisa1, premisa2)

    if operacionRealizar == 'Bicondicional':
        bicondicionalLogico(premisa1, premisa2)

    if operacionRealizar == 'not':

        objetoPremisas[0].negar()
        objetoPremisas[1].negar()
        imprimirPremisas(objetoPremisas)


#----- Flujo general del programa -----#

# Se solicitan las premisas
pedirPresmisas()
# Se muestran las premisas
imprimirPremisas(objetoPremisas)
# Se obtiene la operación a realizar
op = False
while op == False:
    print("\nIngresa una opción válida")
    op = leerOperacion()

# Se realiza la operación ingresada
hacerOperacion(op)