# Función para validar el valor de verdad que el usuario ingresa para cada premisa
def valoresDeVerdad(valor):
    valor = valor.upper()

    if 'V' in valor or 'T' in valor or valor == "1":
        return True

    if 'F' in valor or valor == '0':
        return False

# Función para validad la operación que el usuario quiere realizar
def validarOperacion(entradaTeclado):

    entradaTeclado = entradaTeclado.upper()

    # Validaciones para operación lógica AND

    if 'CONJ' in entradaTeclado:
        return 'and'

    if 'AND' in entradaTeclado:
        return 'and'

    if '&' in entradaTeclado:
        return 'and'

    if '^' in entradaTeclado:
        return 'and'

    if '∧' in entradaTeclado:
        return 'and'

    if '&&' in entradaTeclado:
        return 'and'

    if "Y" in entradaTeclado:
        return 'and'

    # Validaciones para operación lógica OR

    if 'OR' in entradaTeclado:
        return 'or'
    if '∨' in entradaTeclado:
        return 'or'
    if 'v' in entradaTeclado:
        return 'or'
    if '|' in entradaTeclado:
        return 'or'
    if '||' in entradaTeclado:
        return 'or'
    if 'DISYUN' in entradaTeclado:
        return 'or'

    # Validaciones para operación lógica BICONDICIONAL

    if '⇔' in entradaTeclado:
        return 'Bicondicional'

    if '≡' in entradaTeclado:
        return 'Bicondicional'

    if '↔' in entradaTeclado:
        return 'Bicondicional'

    if 'BI' in entradaTeclado:
        return 'Bicondicional'

    if 'Y SOLO' in entradaTeclado:
        return 'Bicondicional'

    if '<->' == entradaTeclado:
        return 'Bicondicional'

    # Validaciones para operación lógica CONDICIONAL

    if '⇒' in entradaTeclado:
        return 'Condicional'

    if '→' in entradaTeclado:
        return 'Condicional'

    if '⊃' in entradaTeclado:
        return 'Condicional'

    if '->' == entradaTeclado:
        return 'Condicional'

    if 'COND' in entradaTeclado:
        return 'Condicional'

    if 'ENTON' in entradaTeclado:
        return 'Condicional'

    if 'SI' in entradaTeclado:
        return 'Condicional'
    
    # Validaciones para operación lógica NOT

    if 'N' in entradaTeclado:
        return 'not'
    
    if 'NOT' in entradaTeclado:
        return 'not'
    
    if '0' in entradaTeclado:
        return 'not'
    
    if '!' in entradaTeclado:
        return 'not'
    
    
    return False