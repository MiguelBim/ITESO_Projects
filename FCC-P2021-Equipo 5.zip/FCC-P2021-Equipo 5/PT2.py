import pandas as pd

def negar(valor1):
    return not valor1

def conjuncion(valor1, valor2):
    return valor1 and valor2

def disyuncion(valor1, valor2):
    return valor1 or valor2

def condicional(valor1, valor2):
    if valor1==True and valor2==False:
        return False
    else:
        return True

def bicondicional(valor1, valor2):
    if valor1==valor2:
        return True
    else:
        return False

lproposiciones=["p", "q","r"]

#primero saber cuantas premisas y cuantas proposiciones se van a usar
npremisas=int(input("Cunatas premisas quieres meter? (minimo 2)\naqui: "))
while npremisas<2:
    npremisas = int(input("Escribe CORRECTAMENTE cunatas premisas quieres meter? (minimo 2)\naqui: "))

nproposiciones=int(input("\nCuantas proposiciones vas a usar? (puedes usar 2 o 3)\naqui: "))
while nproposiciones!=2 and nproposiciones!=3:
    nproposiciones = int(input("Escribe CORRECTAMENTE cuantas proposiciones vas a usar? (puedes usar 2 o 3)\naqui: "))

if nproposiciones==2:
    print(f'\nlas letras que debes de usar son "{lproposiciones[0]}" y "{lproposiciones[1]}"')
elif nproposiciones==3:
    print(f'\nlas letras que debes de usar son "{lproposiciones[0]}", "{lproposiciones[1]}" y "{lproposiciones[2]}"\n'
          f'las operaciones logicas se haran de izquierda a derecha, ejemplo:\n'
          f'"r <=> p ∧ q" el programa lo veria como "(r <=> p) ∧ q"\n'
          f'primero se ejecutaria la parte de la bicondicional por estar a la izquierda\n\n'
          f'entonces si quieres: "p => (q v r)", lo deberias de meter asi:"(q v r) <= p"\n'
          f'todo esto porque el programa da prioridad a las primeras dos proposiciones')


lpremisa=2+(nproposiciones-1)*3

listapremisa=[]

for i in range(0, lpremisa*(npremisas+1), 1):
    listapremisa.append(0)

for i in range(0,npremisas,1):
    print(f'\nPremisa numero {i+1}')
    spropo=int(input(f'Cuantas proposiciones vas a usar en la premisa numero {i+1} (minimo 1 y maximo {nproposiciones})\naqui: '))
    while spropo<1 or spropo>nproposiciones:
        spropo = int(input(f'Escribe CORRECTAMENTE cuantas proposiciones vas a usar en la premisa numero {i + 1} (minimo 1 y maximo {nproposiciones})\naqui: '))

    for j in range(0, spropo, 1):
        ubicacion=1+(3*j)+(i*lpremisa)

        negada=int(input(f'\n¿Va a ir negada tu proposicion numero {j + 1} que vas a usar en la premisa {i + 1}?\n'
                     f'escribe 1 si no se va a negar y 2 si se va a negar\n'
                     f'aqui: '))
        while negada!=1 and negada!=2:
            negada = int(input(f'¿Va a ir negada tu proposicion numero {j + 1} que vas a usar en la premisa {i + 1}?\n'
                               f'escriba CORRECTAMENTE "1" si no se va a negar y "2" si se va a negar\n'
                               f'aqui: '))

        listapremisa[ubicacion-1]=negada

        entradapropo = input(f'\nCual es la proposicion numero {j + 1} que vas a usar en la premisa {i + 1}: ')

        while (entradapropo in lproposiciones[0:nproposiciones])!=True:
            entradapropo = input(f'Escriba la porposicion CORRECTAMENTE: ')

        listapremisa[ubicacion] = entradapropo

    for k in range(0, spropo-1, 1):
        ubicacion=2 +(3*k)+(i*lpremisa)

        operador=int(input(f'\nEscribe el numero de la opcion del operador logico vas a usar entre las porposiciones {k+1} y {k+2}\n'
                           f'1 conjuncion          " ∧ "\n'
                           f'2 disyuncion          " v "\n'
                           f'3 condicional         " => "\n'
                           f'4 bicondicional       " <=> "\n'
                           f'5 condicional inversa " <= "\n'
                           f'aqui: '))
        while operador!=1 and operador!=2 and operador!=3 and operador!=4 and operador!=5:
            operador=int(input("Escribe CORRECTAMENTE la opcion: "))

        listapremisa[ubicacion]=operador+2


print("\n\nLa conclusion")
spropo=int(input(f'Cuantas proposiciones vas a usar en la conclusion (minimo 1 y maximo {nproposiciones})\naqui: '))

while spropo<1 or spropo>nproposiciones:
    spropo = int(input(f'Escribe CORRECTAMENTE cuantas proposiciones vas a usar en la conclusion (minimo 1 y maximo {nproposiciones})\naqui: '))

for j in range(0, spropo, 1):
    ubicacion=1+(3*j)+(lpremisa*npremisas)

    negada=int(input(f'\n¿Va a ir negada tu proposicion numero {j + 1} de la conclusion?\n'
                 f'escribe 1 si no se va a negar y 2 si se va a negar\n'
                 f'aqui: '))
    while negada!=1 and negada!=2:
        negada = int(input(f'¿Va a ir negada tu proposicion numero {j + 1} de la conclusion?\n'
                           f'escriba CORRECTAMENTE "1" si no se va a negar y "2" si se va a negar\n'
                           f'aqui: '))

    listapremisa[ubicacion-1]=negada

    entradapropo = input(f'\nCual es la proposicion numero {j + 1} de la conclusion: ')

    while (entradapropo in lproposiciones[0:nproposiciones]) != True:
        entradapropo = input(f'Escriba la porposicion CORRECTAMENTE: ')

    listapremisa[ubicacion] = entradapropo


for k in range(0, spropo-1, 1):
    ubicacion=2 +(3*k)+(lpremisa*npremisas)

    operador=int(input(f'\nEscribe el numero de la opcion del operador logico vas a usar entre las porposiciones {k+1} y {k+2}\n'
                       f'1 conjuncion          " ∧ "\n'
                       f'2 disyuncion          " v "\n'
                       f'3 condicional         " => "\n'
                       f'4 bicondicional       " <=> "\n'
                       f'5 condicional inversa " <= "\n'
                       f'aqui: '))
    while operador!=1 and operador!=2 and operador!=3 and operador!=4 and operador!=5:
        operador=int(input("Escribe CORRECTAMENTE la opcion: "))

    listapremisa[ubicacion]=operador+2


printpremisa=[]
for i in range(0, npremisas+1,1):
    printpremisa.append("0")
guardarpremisa=""
contador=0

print("\nEstas son las premisas y la conclusion:")
for i in range(0,lpremisa*(npremisas+1), 1):
    if listapremisa[i]==0 or listapremisa[i]==1:
        pass

    elif listapremisa[i]==2:
        print("∼", end="")
        guardarpremisa  += "∼"

    elif listapremisa[i]==3:
        print(" ∧ ", end="")
        guardarpremisa  += " ∧ "

    elif listapremisa[i]==4:
        print(" v ", end="")
        guardarpremisa  += " v "

    elif listapremisa[i]==5:
        print(" => ", end="")
        guardarpremisa  += " => "

    elif listapremisa[i]==6:
        print(" <=> ", end="")
        guardarpremisa += " <=> "

    elif listapremisa[i]==7:
        print(" <= ", end="")
        guardarpremisa += " <= "

    else:
        print(listapremisa[i], end="")
        guardarpremisa += "".join(listapremisa[i])

    if (i+1)%lpremisa==0:
        #print(guardarpremisa)
        printpremisa[contador]=guardarpremisa
        guardarpremisa = ""
        contador+=1
        print()

#print(printpremisa)

if nproposiciones==2:
    columnas = ['p', 'q']
    nrenglones = 4
    vfcolumnas = [True, True, False, False, True, False, True, False]

    tabla1 = pd.DataFrame(
        {
            lproposiciones[0]: vfcolumnas[0:nrenglones],
            lproposiciones[1]: vfcolumnas[nrenglones:nrenglones * 2]
        }
    )

elif nproposiciones==3:
    columnas = ['p', 'q', 'r']
    nrenglones = 8
    vfcolumnas = [True, True, True, True, False, False, False, False, True, True, False, False, True, True, False,
                  False, True, False, True, False, True, False, True, False]

    tabla1 = pd.DataFrame(
        {
            lproposiciones[0]: vfcolumnas[0:nrenglones],
            lproposiciones[1]: vfcolumnas[nrenglones:nrenglones * 2],
            lproposiciones[2]: vfcolumnas[nrenglones * 2:nrenglones * 3]
        }
    )


for i in range(0, npremisas+1, 1):

    listcopy = listapremisa.copy()
    while (2 in listcopy[i*lpremisa:(i+1)*lpremisa])==True:
        ubicacion=listcopy[i*lpremisa:(i+1)*lpremisa].index(2)
        ubicacion += i * lpremisa

        guardarpremisa="∼"
        guardarpremisa+="".join(listcopy[ubicacion+1])

        letra=listcopy[ubicacion+1]
        ubiletra=columnas.index(letra)

        if guardarpremisa in columnas:
            pass
        else:
            columnas.append(guardarpremisa)
            for j in range(0, nrenglones, 1):
                vfcolumnas.append(negar(vfcolumnas[j+nrenglones*ubiletra]))

        listcopy[ubicacion]=0


    listcopy = listapremisa.copy()
    if 3 == listcopy[i*lpremisa+2] or 4 == listcopy[i*lpremisa+2] or 5 == listcopy[i*lpremisa+2] or 6 == listcopy[i*lpremisa+2] or 7 == listcopy[i*lpremisa+2]:
        guardarpremisa = ""
        ubicacion = i*lpremisa+2

        if listcopy[ubicacion-2]==2:#ubicacion -2
            guardarpremisa+="∼"

        guardarpremisa+="".join(listcopy[ubicacion-1])#ubicacion -1

        letra1=guardarpremisa
        ubiletra1=columnas.index(letra1)


        if listcopy[ubicacion] == 3:#ubicacion 0
            logico= " ∧ "
        elif listcopy[ubicacion] == 4:
            logico= " v "
        elif listcopy[ubicacion] == 5:
            logico= " => "
        elif listcopy[ubicacion] == 6:
            logico = " <=> "
        elif listcopy[ubicacion] == 7:
            logico = " <= "

        guardarpremisa=""
        if listcopy[ubicacion+1]==2:#ubicacion 1
            guardarpremisa+="∼"

        guardarpremisa += "".join(listcopy[ubicacion+2])#ubicacion 2

        letra2=guardarpremisa
        ubiletra2 = columnas.index(letra2)

        guardarpremisa=letra1+logico+letra2

        if guardarpremisa in columnas:
            pass
        else:
            columnas.append(guardarpremisa)
            for j in range(0, nrenglones, 1):
                if listcopy[ubicacion]==3:
                    vfcolumnas.append(conjuncion(vfcolumnas[j+nrenglones*ubiletra1],vfcolumnas[j+nrenglones*ubiletra2]))
                elif listcopy[ubicacion]==4:
                    vfcolumnas.append(disyuncion(vfcolumnas[j + nrenglones * ubiletra1], vfcolumnas[j + nrenglones * ubiletra2]))
                elif listcopy[ubicacion]==5:
                    vfcolumnas.append(condicional(vfcolumnas[j + nrenglones * ubiletra1], vfcolumnas[j + nrenglones * ubiletra2]))
                elif listcopy[ubicacion]==6:
                    vfcolumnas.append(bicondicional(vfcolumnas[j + nrenglones * ubiletra1], vfcolumnas[j + nrenglones * ubiletra2]))
                elif listcopy[ubicacion]==7:
                    vfcolumnas.append(condicional(vfcolumnas[j + nrenglones * ubiletra2], vfcolumnas[j + nrenglones * ubiletra1]))

    if printpremisa[i] in columnas:
        pass
    else:
        columnas.append(printpremisa[i])

        letra1=guardarpremisa
        ubiletra1 = columnas.index(letra1)

        letra2=""
        if listcopy[i*lpremisa+lpremisa-2]==2:
            letra2+="∼"

        letra2+=listcopy[i*lpremisa+lpremisa-1]
        ubiletra2= columnas.index(letra2)

        ubicacion=i*lpremisa+lpremisa-3

        for j in range(0, nrenglones, 1):
            if listcopy[ubicacion] == 3:
                vfcolumnas.append(conjuncion(vfcolumnas[j + nrenglones * ubiletra1], vfcolumnas[j + nrenglones * ubiletra2]))
            elif listcopy[ubicacion] == 4:
                vfcolumnas.append(disyuncion(vfcolumnas[j + nrenglones * ubiletra1], vfcolumnas[j + nrenglones * ubiletra2]))
            elif listcopy[ubicacion] == 5:
                vfcolumnas.append(condicional(vfcolumnas[j + nrenglones * ubiletra1], vfcolumnas[j + nrenglones * ubiletra2]))
            elif listcopy[ubicacion] == 6:
                vfcolumnas.append(bicondicional(vfcolumnas[j + nrenglones * ubiletra1], vfcolumnas[j + nrenglones * ubiletra2]))
            elif listcopy[ubicacion] == 7:
                vfcolumnas.append(condicional(vfcolumnas[j + nrenglones * ubiletra2], vfcolumnas[j + nrenglones * ubiletra1]))


#print(columnas)

ncolumnas=len(columnas)-nproposiciones

for i in range(0, ncolumnas, 1):
    tabla2= pd.DataFrame(
        {
            columnas[i+nproposiciones]: vfcolumnas[nproposiciones*nrenglones+nrenglones*i:nproposiciones*nrenglones+nrenglones*i+nrenglones],
        }
    )
    tabla1= pd.concat([tabla1,tabla2], axis=1)


print("\n   Tabla de verdad:")
print(tabla1)

sino=int(input('\nen caso de que la tabla no salga completa \n'
           'escribe "1" para enseñar completa en otro formato o escirbe "2" para terminar el programa\naqui: '))
if sino==1:
    print("\ncontenido de la tabla de verdad")
    m=0
    for i in range(0,len(vfcolumnas), 1):
        if i % nrenglones == 0:
            print(f'{columnas[m]}: ', end=" ")
            m+=1
        print(vfcolumnas[i], end=" ")
        if (i+nrenglones+1)%nrenglones==0:
            print()

print("\ntenga un buen dia")