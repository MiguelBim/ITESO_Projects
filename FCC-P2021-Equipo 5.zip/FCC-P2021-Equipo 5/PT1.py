entradas=int(input("Ingresa el numero de entradas: "))
listaEntradas=[]
listaValor=[]


for i in range(entradas):
    variable=input(f'Cual es tu variable {i+1}: ')
    listaEntradas.append(variable)
    valor=input('Escribe "v" si la variable es verdadera y "f" si la variable es falsa\naqui: ')

    while valor !="v" and valor !="f":
        valor = input('Escribe CORRECTAMENTE "v" si la variable es verdadera y "f" si la variable es falsa\naqui: ')

    listaValor.append(valor)

orAnd=input('Escribe "or" si quieres disyuncion, "and" si quieres conjuncion, ">" si quieres condicional, "<>" si quieres bicondicional o "not" si quieres  negacion: ')
while orAnd !="or" and orAnd !="and" and orAnd !=">" and orAnd != "<>" and orAnd != "not":
    orAnd = input('Escribe CORRECTAMENTE "or" si quieres disyuncion, "and" si quieres conjuncion, ">" si quieres condicional, "<>" si quieres bicondicional o "not" si quieres  negacion: ')

print("\n")

print("el valor de tu oracion es:")
if orAnd=="or":
    if "v" in listaValor:
        print("V")
    else:
        print("F")

elif (orAnd == "and"):
    if "f" in listaValor:
        print("F")
    else:
        print("V")

elif(orAnd == ">"):
    if ("v" in listaValor[0]) and ("f" in listaValor[1]):
        print("F")
    else:
        print("V")

elif(orAnd == "<>"):
    if("v" in listaValor[0])and ("f" in listaValor[1]):
        print("F")
    elif("f" in listaValor[0]) and ("v" in listaValor[1]):
        print("F")

    else:
        print("V")

elif(orAnd == 'not'):
    for i in range(entradas):
        elnot=listaValor[i]
        if elnot=="v":
            elnot="f"
        else:
            elnot="v"
        print(f'la variable {i+1} es {elnot}')


listaVariables= ["p","q"]


print("\n")

print(listaEntradas)
if(entradas ==2):
    print(listaVariables)
print(listaValor)

