import pandas as pd

#Hacer tabla de balores V y F
variables = int(input("ingoresa el numero de variables: "))
if variables == 1:
    premisa1 = input("ingresa la letra de tu premisa: ")
    tabla_valores = pd.DataFrame({premisa1 : ["V", "F"]})
    # tabla de operacion
    expresion = input("ingresa tu exprecion: ")
    tabla_operacion = pd.DataFrame({"-->": ["", ""],
                                    expresion: ["", ""]})
    tabla_final = pd.concat([tabla_valores, tabla_operacion], axis=1)
if variables == 2:
    premisa1 = input("ingresa la letra de tu primera premisa: ")
    premisa2 = input("ingresa la letra de tu segunda premisa: ")
    tabla_valores = pd.DataFrame({premisa1 : ["V","V","F","F"],
                                  premisa2 : ["V","F","V","F"]})
    #tabla de operacion
    expresion = input("ingresa tu exprecion: ")
    tabla_operacion = pd.DataFrame({"-->": ["", "", "", ""],
                                    expresion: ["", "", "", ""]})
    tabla_final = pd.concat([tabla_valores, tabla_operacion], axis=1)
if variables == 3:
    premisa1 = input("ingresa la letra de tu primera premisa: ")
    premisa2 = input("ingresa la letra de tu segunda premisa: ")
    premisa3 = input("ingresa la letra de tu tercera premisa: ")
    tabla_valores = pd.DataFrame({premisa1: ["V", "V", "V", "V", "F", "F", "F", "F"],
                                  premisa2: ["V", "V", "F", "F", "V", "V", "F", "F"],
                                  premisa3: ["V", "F", "V", "F", "V", "F", "V", "F"]})
    # tabla de operacion
    expresion = input("ingresa tu exprecion: ")
    tabla_operacion = pd.DataFrame({"-->": ["", "", "", "", "", "", "", ""],
                                    expresion: ["", "", "", "", "", "", "", ""]})
    tabla_final = pd.concat([tabla_valores, tabla_operacion], axis=1)
print(tabla_final)