import pandas as pd

print("=========================\n")
print("Este programa esta hecho para 3 premisas y 2 operaciones, no recive negaciones.\n")
print("Conjuncion(&)\nDisyuncion(|)\nCondicional(>)\nBicondicional(-)\n")
print("ejemplo de operacion: (p|q)&r\n")
print("=========================\n")

premisa1 = input("ingresa la letra de tu primera premisa: ")
simbolo1 = input("cual es el simbolo de tu primera operacion: ")
premisa2 = input("ingresa la letra de tu segunda premisa: ")
simbolo2 = input("cual es el simbolo de tu segunda operacion: ")
premisa3 = input("ingresa la letra de tu tercera premisa: ")


tabla_valores = pd.DataFrame({premisa1: [True, True, True, True, False, False, False, False],
                                  premisa2: [True, True, False, False, True, True, False, False ],
                                  premisa3 + " " : [True, False, True, False, True, False, True, False ],
                                  premisa1 +" "+ simbolo1 +" "+ premisa2 +" " : [None, None, None, None, None, None, None, None],
                                  "("+premisa1 +" "+ simbolo1 +" "+ premisa2 + ")" + simbolo2 + " " + premisa3 :
                                  [None, None, None, None, None, None, None, None]})



def disyuncion1():
    for i in range(8):
        val1 = tabla_valores.loc[i, premisa1]
        val2 = tabla_valores.loc[i, premisa2]
        valor = val1 or val2
        tabla_valores.loc[i, premisa1 +" "+ simbolo1 +" "+ premisa2 +" "] = valor
def conjuncion1():
    for i in range(8):
        val1 = tabla_valores.loc[i, premisa1]
        val2 = tabla_valores.loc[i, premisa2]
        valor = val1 and val2
        tabla_valores.loc[i, premisa1 +" "+ simbolo1 +" "+ premisa2 +" "] = valor
def condicional1():
    for i in range(8):
        val1 = tabla_valores.loc[i, premisa1]
        val2 = tabla_valores.loc[i, premisa2]
        if (val1 == False) and (val2 == True):
            valor = False
        else:
            valor = True
        tabla_valores.loc[i, premisa1 +" "+ simbolo1 +" "+ premisa2 +" "] = valor
def bicondicional1():
    for i in range(8):
        val1 = tabla_valores.loc[i, premisa1]
        val2 = tabla_valores.loc[i, premisa2]
        if ((val1 == False) and (val2 == False)) or ((val1 == True) and (val2 == True)):
            valor = True
        else:
            valor = False
        tabla_valores.loc[i, premisa1 +" "+ simbolo1 +" "+ premisa2 +" "] = valor



def disyuncion2():
    for i in range(8):
        val1 = tabla_valores.loc[i, premisa1 +" "+ simbolo1 +" "+ premisa2 +" "]
        val2 = tabla_valores.loc[i, premisa3 + " " ]
        valor = val1 or val2
        tabla_valores.loc[i, "("+premisa1 +" "+ simbolo1 +" "+ premisa2 + ")" + simbolo2 + " " + premisa3 ] = valor
def conjuncion2():
    for i in range(8):
        val1 = tabla_valores.loc[i, premisa1 + " " + simbolo1 + " " + premisa2 + " "]
        val2 = tabla_valores.loc[i, premisa3 + " " ]
        valor = val1 and val2
        tabla_valores.loc[i, "("+premisa1 +" "+ simbolo1 +" "+ premisa2 + ")" + simbolo2 + " " + premisa3 ] = valor
def condicional2():
    for i in range(8):
        val1 = tabla_valores.loc[i, premisa1 + " " + simbolo1 + " " + premisa2 + " "]
        val2 = tabla_valores.loc[i, premisa3 + " " ]
        if (val1 == False) and (val2 == True):
            valor = False
        else:
            valor = True
        tabla_valores.loc[i, "("+premisa1 +" "+ simbolo1 +" "+ premisa2 + ")" + simbolo2 + " " + premisa3 ] = valor
def bicondicional2():
    for i in range(8):
        val1 = tabla_valores.loc[i, premisa1 + " " + simbolo1 + " " + premisa2 + " "]
        val2 = tabla_valores.loc[i, premisa3 + " " ]
        if ((val1 == False) and (val2 == False)) or ((val1 == True) and (val2 == True)):
            valor = True
        else:
            valor = False
        tabla_valores.loc[i, "("+premisa1 +" "+ simbolo1 +" "+ premisa2 + ")" + simbolo2 + " " + premisa3 ] = valor



if simbolo1 == "&":
    conjuncion1()
elif simbolo1 == "|":
    disyuncion1()
elif simbolo1 == ">":
    condicional1()
elif simbolo1 == "-":
    bicondicional1()

if simbolo2 == "&":
    conjuncion2()
elif simbolo2 == "|":
    disyuncion2()
elif simbolo2 == ">":
    condicional2()
elif simbolo2 == "-":
    bicondicional2()




print(tabla_valores)
print("")
for i in range(8):
    a = tabla_valores.loc[i,premisa1 +" "+ simbolo1 +" "+ premisa2 +" "]
    b = tabla_valores.loc[i,"("+premisa1 +" "+ simbolo1 +" "+ premisa2 + ")" + simbolo2 + " " + premisa3]
    if (a == True) and (b == True):
        print(f" La fila {i} Es una constante")