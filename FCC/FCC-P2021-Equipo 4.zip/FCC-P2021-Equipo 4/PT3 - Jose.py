import pandas as pd
print("=========================\n")
print("Este programa esta hecho para 3 premisas y 2 operaciones, no recive negaciones.\n")
print("Conjuncion(&)\nDisyuncion(|)\nCondicional(>)\nBicondicional(-)\n")
print("ejemplo de operacion: (p|q)&r\n")
print("=========================\n")
premisa1 = input("ingresa la letra de tu primera premisa: ")
simbolo1 = input("cual es el simbolo de tu primera operacion: ")
premisa2 = input("ingresa la letra de tu segunda premisa: ")
simbolo2 = input("cual es el simbolo de tu segunda operacion: ")
premisa3 = input("ingresa la letra de tu tercera premisa: ")

print("================================================")
print("Ingresa tu segunda premisa: \n")
premisa1A = input("ingresa la letra de tu primera premisa: ")
simbolo1A = input("cual es el simbolo de tu primera operacion: ")
premisa2A = input("ingresa la letra de tu segunda premisa: ")
simbolo2A = input("cual es el simbolo de tu segunda operacion: ")
premisa3A = input("ingresa la letra de tu tercera premisa: ")

print("=================================================")
print("ingresa tu conclusion: \n ejemplo: p > q")
conclusion_premisa1 = input("ingresa la letra de tu primera conclusion: ")
conclusion_simbolo = input("ingresa el simbolo de tu conclusion: ")
conclusion_premisa2 = input("ingresa la letra de tu segunda conclusion: ")

tabla_valores = pd.DataFrame({premisa1: [True, True, True, True, False, False, False, False],
                                  premisa2: [True, True, False, False, True, True, False, False ],
                                  premisa3 + " " : [True, False, True, False, True, False, True, False ],
                                  premisa1 +" "+ simbolo1 +" "+ premisa2 +" " : [None, None, None, None, None, None, None, None],
                                  "("+premisa1 +" "+ simbolo1 +" "+ premisa2 + ")" + simbolo2 + " " + premisa3 :
                                  [None, None, None, None, None, None, None, None]})

tabla_valoresA = pd.DataFrame({premisa1A: [True, True, True, True, False, False, False, False],
                                  premisa2A: [True, True, False, False, True, True, False, False ],
                                  premisa3A + " " : [True, False, True, False, True, False, True, False ],
                                  premisa1A +" "+ simbolo1A +" "+ premisa2A +" " : [None, None, None, None, None, None, None, None],
                                  "("+premisa1A +" "+ simbolo1A +" "+ premisa2A + ")" + simbolo2A + " " + premisa3A :
                                  [None, None, None, None, None, None, None, None]})



def disyuncion1():
    for i in range(8):
        val1 = tabla_valores.loc[i, premisa1]
        val2 = tabla_valores.loc[i, premisa2]
        valor = val1 or val2
        tabla_valores.loc[i, premisa1 +" "+ simbolo1 +" "+ premisa2 +" "] = valor
def conjuncion1():
    for i in range(8):
        val1 = tabla_valores.loc[i, premisa1]
        val2 = tabla_valores.loc[i, premisa2]
        valor = val1 and val2
        tabla_valores.loc[i, premisa1 +" "+ simbolo1 +" "+ premisa2 +" "] = valor
def condicional1():
    for i in range(8):
        val1 = tabla_valores.loc[i, premisa1]
        val2 = tabla_valores.loc[i, premisa2]
        if (val1 == False) and (val2 == True):
            valor = False
        else:
            valor = True
        tabla_valores.loc[i, premisa1 +" "+ simbolo1 +" "+ premisa2 +" "] = valor
def bicondicional1():
    for i in range(8):
        val1 = tabla_valores.loc[i, premisa1]
        val2 = tabla_valores.loc[i, premisa2]
        if ((val1 == False) and (val2 == False)) or ((val1 == True) and (val2 == True)):
            valor = True
        else:
            valor = False
        tabla_valores.loc[i, premisa1 +" "+ simbolo1 +" "+ premisa2 +" "] = valor

def disyuncion2():
    for i in range(8):
        val1 = tabla_valores.loc[i, premisa1 +" "+ simbolo1 +" "+ premisa2 +" "]
        val2 = tabla_valores.loc[i, premisa3 + " " ]
        valor = val1 or val2
        tabla_valores.loc[i, "("+premisa1 +" "+ simbolo1 +" "+ premisa2 + ")" + simbolo2 + " " + premisa3 ] = valor
def conjuncion2():
    for i in range(8):
        val1 = tabla_valores.loc[i, premisa1 + " " + simbolo1 + " " + premisa2 + " "]
        val2 = tabla_valores.loc[i, premisa3 + " " ]
        valor = val1 and val2
        tabla_valores.loc[i, "("+premisa1 +" "+ simbolo1 +" "+ premisa2 + ")" + simbolo2 + " " + premisa3 ] = valor
def condicional2():
    for i in range(8):
        val1 = tabla_valores.loc[i, premisa1 + " " + simbolo1 + " " + premisa2 + " "]
        val2 = tabla_valores.loc[i, premisa3 + " " ]
        if (val1 == False) and (val2 == True):
            valor = False
        else:
            valor = True
        tabla_valores.loc[i, "("+premisa1 +" "+ simbolo1 +" "+ premisa2 + ")" + simbolo2 + " " + premisa3 ] = valor
def bicondicional2():
    for i in range(8):
        val1 = tabla_valores.loc[i, premisa1 + " " + simbolo1 + " " + premisa2 + " "]
        val2 = tabla_valores.loc[i, premisa3 + " " ]
        if ((val1 == False) and (val2 == False)) or ((val1 == True) and (val2 == True)):
            valor = True
        else:
            valor = False
        tabla_valores.loc[i, "("+premisa1 +" "+ simbolo1 +" "+ premisa2 + ")" + simbolo2 + " " + premisa3 ] = valor



def disyuncion1A():
    for i in range(8):
        val1 = tabla_valoresA.loc[i, premisa1A]
        val2 = tabla_valoresA.loc[i, premisa2A]
        valor = val1 or val2
        tabla_valoresA.loc[i, premisa1A +" "+ simbolo1A +" "+ premisa2A +" "] = valor
def conjuncion1A():
    for i in range(8):
        val1 = tabla_valoresA.loc[i, premisa1A]
        val2 = tabla_valoresA.loc[i, premisa2A]
        valor = val1 and val2
        tabla_valoresA.loc[i, premisa1A +" "+ simbolo1A +" "+ premisa2A +" "] = valor
def condicional1A():
    for i in range(8):
        val1 = tabla_valoresA.loc[i, premisa1A]
        val2 = tabla_valoresA.loc[i, premisa2A]
        if (val1 == True) and (val2 == False):
            valor = False
        else:
            valor = True
        tabla_valoresA.loc[i, premisa1A +" "+ simbolo1A +" "+ premisa2A +" "] = valor
def bicondicional1A():
    for i in range(8):
        val1 = tabla_valoresA.loc[i, premisa1A]
        val2 = tabla_valoresA.loc[i, premisa2A]
        if ((val1 == False) and (val2 == False)) or ((val1 == True) and (val2 == True)):
            valor = True
        else:
            valor = False
        tabla_valoresA.loc[i, premisa1A +" "+ simbolo1A +" "+ premisa2A +" "] = valor

def disyuncion2A():
    for i in range(8):
        val1 = tabla_valoresA.loc[i, premisa1A +" "+ simbolo1A +" "+ premisa2A +" "]
        val2 = tabla_valoresA.loc[i, premisa3A + " " ]
        valor = val1 or val2
        tabla_valoresA.loc[i, "("+premisa1A +" "+ simbolo1A +" "+ premisa2A + ")" + simbolo2A + " " + premisa3A ] = valor
def conjuncion2A():
    for i in range(8):
        val1 = tabla_valoresA.loc[i, premisa1A + " " + simbolo1A + " " + premisa2A + " "]
        val2 = tabla_valoresA.loc[i, premisa3A + " " ]
        valor = val1 and val2
        tabla_valoresA.loc[i, "("+premisa1A +" "+ simbolo1A +" "+ premisa2A + ")" + simbolo2A + " " + premisa3A ] = valor
def condicional2A():
    for i in range(8):
        val1 = tabla_valoresA.loc[i, premisa1A + " " + simbolo1A + " " + premisa2A + " "]
        val2 = tabla_valoresA.loc[i, premisa3A + " " ]
        if (val1 == True) and (val2 == False):
            valor = False
        else:
            valor = True
        tabla_valoresA.loc[i, "("+premisa1A +" "+ simbolo1A +" "+ premisa2A + ")" + simbolo2A + " " + premisa3A ] = valor
def bicondicional2A():
    for i in range(8):
        val1 = tabla_valoresA.loc[i, premisa1A + " " + simbolo1A + " " + premisa2A + " "]
        val2 = tabla_valoresA.loc[i, premisa3A + " " ]
        if ((val1 == False) and (val2 == False)) or ((val1 == True) and (val2 == True)):
            valor = True
        else:
            valor = False
        tabla_valoresA.loc[i, "("+premisa1A +" "+ simbolo1A +" "+ premisa2A + ")" + simbolo2A + " " + premisa3A ] = valor

if simbolo1A == "&":
    conjuncion1A()
elif simbolo1A == "|":
    disyuncion1A()
elif simbolo1A == ">":
    condicional1A()
elif simbolo1A == "-":
    bicondicional1A()
if simbolo2A == "&":
    conjuncion2A()
elif simbolo2A == "|":
    disyuncion2A()
elif simbolo2A == ">":
    condicional2A()
elif simbolo2A == "-":
    bicondicional2A()


if simbolo1 == "&":
    conjuncion1()
elif simbolo1 == "|":
    disyuncion1()
elif simbolo1 == ">":
    condicional1()
elif simbolo1 == "-":
    bicondicional1()
if simbolo2 == "&":
    conjuncion2()
elif simbolo2 == "|":
    disyuncion2()
elif simbolo2 == ">":
    condicional2()
elif simbolo2 == "-":
    bicondicional2()

tabla_conclusion = pd.DataFrame({ premisa1: [True, True, True, True, False, False, False, False],
                                  premisa2: [True, True, False, False, True, True, False, False],
                                  premisa3: [True, False, True, False, True, False, True, False],
                                "("+premisa1 +" "+ simbolo1 +" "+ premisa2 + ")" + simbolo2 + " " + premisa3 :
                                  [None, None, None, None, None, None, None, None],
                                 "(" + premisa1A + " " + simbolo1A + " " + premisa2A + ")" + simbolo2A + " " + premisa3A:
                                  [None, None, None, None, None, None, None, None],
                                 conclusion_premisa1 +" "+ conclusion_simbolo +" "+ conclusion_premisa2:
                                  [None, None, None, None, None, None, None, None]})

for j in range(8):
    tabla_conclusion.loc[j, "("+premisa1 +" "+ simbolo1 +" "+ premisa2 + ")" + simbolo2 + " " + premisa3] = tabla_valores.loc[j,"("+premisa1 +" "+ simbolo1 +" "+ premisa2 + ")" + simbolo2 + " " + premisa3]
    tabla_conclusion.loc[j,"(" + premisa1A + " " + simbolo1A + " " + premisa2A + ")" + simbolo2A + " " + premisa3A] = tabla_valoresA.loc[j,"(" + premisa1A + " " + simbolo1A + " " + premisa2A + ")" + simbolo2A + " " + premisa3A]

if conclusion_premisa1 == premisa1:
    if conclusion_premisa2 == premisa2:
        for i in range(8):
            val1 = tabla_conclusion.loc[i, premisa1]
            val2 = tabla_conclusion.loc[i, premisa2]
            if (val1 == True) and (val2 == False):
                valor = False
            else:
                valor = True
            tabla_conclusion.loc[i, conclusion_premisa1 +" "+ conclusion_simbolo +" "+ conclusion_premisa2] = valor
    elif conclusion_premisa2 == premisa3:
        for i in range(8):
            val1 = tabla_conclusion.loc[i, premisa1]
            val2 = tabla_conclusion.loc[i, premisa3]
            if (val1 == True) and (val2 == False):
                valor = False
            else:
                valor = True
            tabla_conclusion.loc[i, conclusion_premisa1 + " " + conclusion_simbolo + " " + conclusion_premisa2] = valor
elif conclusion_premisa1 == premisa2:
    if conclusion_premisa2 == premisa1:
        for i in range(8):
            val1 = tabla_conclusion.loc[i, premisa2]
            val2 = tabla_conclusion.loc[i, premisa1]
            if (val1 == True) and (val2 == False):
                valor = False
            else:
                valor = True
            tabla_conclusion.loc[i, conclusion_premisa1 + " " + conclusion_simbolo + " " + conclusion_premisa2] = valor

    elif conclusion_premisa2 == premisa3:
        for i in range(8):
            val1 = tabla_conclusion.loc[i, premisa2]
            val2 = tabla_conclusion.loc[i, premisa3]
            if (val1 == True) and (val2 == False):
                valor = False
            else:
                valor = True
            tabla_conclusion.loc[i, conclusion_premisa1 + " " + conclusion_simbolo + " " + conclusion_premisa2] = valor

elif conclusion_premisa1 == premisa3:
    if conclusion_premisa2 == premisa1:
        for i in range(8):
            val1 = tabla_conclusion.loc[i, premisa3]
            val2 = tabla_conclusion.loc[i, premisa1]
            if (val1 == True) and (val2 == False):
                valor = False
            else:
                valor = True
            tabla_conclusion.loc[i, conclusion_premisa1 + " " + conclusion_simbolo + " " + conclusion_premisa2] = valor

    elif conclusion_premisa2 == premisa2:
        for i in range(8):
            val1 = tabla_conclusion.loc[i, premisa3]
            val2 = tabla_conclusion.loc[i, premisa2]
            if (val1 == True) and (val2 == False):
                valor = False
            else:
                valor = True
            tabla_conclusion.loc[i, conclusion_premisa1 + " " + conclusion_simbolo + " " + conclusion_premisa2] = valor



print(tabla_valores)
print("")
print(tabla_valoresA)
print("")
print(tabla_conclusion)

for i in range(8):
    a = tabla_conclusion.loc[i,"("+premisa1 +" "+ simbolo1 +" "+ premisa2 + ")" + simbolo2 + " " + premisa3]
    b = tabla_conclusion.loc[i,"(" + premisa1A + " " + simbolo1A + " " + premisa2A + ")" + simbolo2A + " " + premisa3A]
    c = tabla_conclusion.loc[i,conclusion_premisa1 +" "+ conclusion_simbolo +" "+ conclusion_premisa2]
    if (a == True) and (b == True) and (c == True):
        print(f"\n La fila {i} Es un renglon Critico")
