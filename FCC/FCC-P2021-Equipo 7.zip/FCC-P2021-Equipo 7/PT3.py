import pandas as pd

#Christian Alejandro Pereda González
#Said Gabriel Santana García
#Diego Solórzano Castañeda

Fin = []
Fin2 = []
Fin3 = []

f1 = ["V", "V", "F", "F"]
f2 = ["V", "F", "V", "F"]

vn = [1, 1, -1, -1]
vn2 = [1, -1, 1, -1]

f1v = ["F", "F", "V", "V"]
f2v = ["F", "V", "F", "V"]

vnv = [-1, -1, 1, 1]
vn2v = [-1, 1, -1, 1]

dip = 0
dip2 = 0

pvof3 = 0
qvof3 = 0

# f1: Valores de verdad de P
# f2: Valores de verdad de Q

# f1v: Valores de verdad de ~P
# f2v: Valores de verdad de ~Q

# vn: tablas de verdad pero en nums

# pvof y qvof: Si las premisas Q y P están negadas

# cn: conector lógico usado
# Fin y Fin2: lista para guardar las tablas de verdad de las premisas ej: p V q


#CONECTORES P1
def disyuncion():
    dip = pvof
    dip2 = qvof
    if pvof == 1 and qvof == 1:
        for i in range(0, 4, 1):
            if vn[i] == 1 and vn2[i] == 1:
                Fin.append("V")
            if vn[i] == 1 and vn2[i] == -1:
                Fin.append("V")
            if vn[i] == -1 and vn2[i] == 1:
                Fin.append("V")
            if vn[i] == -1 and vn2[i] == -1:
                Fin.append("F")
    if pvof == 1 and qvof == -1:
        for i in range(0, 4, 1):
            if vn[i] == 1 and vn2v[i] == 1:
                Fin.append("V")
            if vn[i] == 1 and vn2v[i] == -1:
                Fin.append("V")
            if vn[i] == -1 and vn2v[i] == 1:
                Fin.append("V")
            if vn[i] == -1 and vn2v[i] == -1:
                Fin.append("F")
    if pvof == -1 and qvof == 1:
        for i in range(0, 4, 1):
            if vnv[i] == 1 and vn2[i] == 1:
                Fin.append("V")
            if vnv[i] == 1 and vn2[i] == -1:
                Fin.append("V")
            if vnv[i] == -1 and vn2[i] == 1:
                Fin.append("V")
            if vnv[i] == -1 and vn2[i] == -1:
                Fin.append("F")
    if pvof == -1 and qvof == -1:
        for i in range(0, 4, 1):
            if vnv[i] == 1 and vn2v[i] == 1:
                Fin.append("V")
            if vnv[i] == 1 and vn2v[i] == -1:
                Fin.append("V")
            if vnv[i] == -1 and vn2v[i] == 1:
                Fin.append("V")
            if vnv[i] == -1 and vn2v[i] == -1:
                Fin.append("F")
def conjuncion():
    if pvof == 1 and qvof == 1:
        for i in range(0, 4, 1):
            if vn[i] == 1 and vn2[i] == 1:
                Fin.append("V")
            if vn[i] == 1 and vn2[i] == -1:
                Fin.append("F")
            if vn[i] == -1 and vn2[i] == 1:
                Fin.append("F")
            if vn[i] == -1 and vn2[i] == -1:
                Fin.append("F")
    if pvof == 1 and qvof == -1:
        for i in range(0, 4, 1):
            if vn[i] == 1 and vn2v[i] == 1:
                Fin.append("V")
            if vn[i] == 1 and vn2v[i] == -1:
                Fin.append("F")
            if vn[i] == -1 and vn2v[i] == 1:
                Fin.append("F")
            if vn[i] == -1 and vn2v[i] == -1:
                Fin.append("F")
    if pvof == -1 and qvof == 1:
        for i in range(0, 4, 1):
            if vnv[i] == 1 and vn2[i] == 1:
                Fin.append("V")
            if vnv[i] == 1 and vn2[i] == -1:
                Fin.append("F")
            if vnv[i] == -1 and vn2[i] == 1:
                Fin.append("F")
            if vnv[i] == -1 and vn2[i] == -1:
                Fin.append("F")
    if pvof == -1 and qvof == -1:
        for i in range(0, 4, 1):
            if vnv[i] == 1 and vn2v[i] == 1:
                Fin.append("V")
            if vnv[i] == 1 and vn2v[i] == -1:
                Fin.append("F")
            if vnv[i] == -1 and vn2v[i] == 1:
                Fin.append("F")
            if vnv[i] == -1 and vn2v[i] == -1:
                Fin.append("F")
def Condicionalidad():
    if pvof == 1 and qvof == 1:
        for i in range(0, 4, 1):
            if vn[i] == 1 and vn2[i] == 1:
                Fin.append("V")
            if vn[i] == 1 and vn2[i] == -1:
                Fin.append("F")
            if vn[i] == -1 and vn2[i] == 1:
                Fin.append("V")
            if vn[i] == -1 and vn2[i] == -1:
                Fin.append("V")
    if pvof == 1 and qvof == -1:
        for i in range(0, 4, 1):
            if vn[i] == 1 and vn2v[i] == 1:
                Fin.append("V")
            if vn[i] == 1 and vn2v[i] == -1:
                Fin.append("F")
            if vn[i] == -1 and vn2v[i] == 1:
                Fin.append("V")
            if vn[i] == -1 and vn2v[i] == -1:
                Fin.append("V")
    if pvof == -1 and qvof == 1:
        for i in range(0, 4, 1):
            if vnv[i] == 1 and vn2[i] == 1:
                Fin.append("V")
            if vnv[i] == 1 and vn2[i] == -1:
                Fin.append("F")
            if vnv[i] == -1 and vn2[i] == 1:
                Fin.append("V")
            if vnv[i] == -1 and vn2[i] == -1:
                Fin.append("V")
    if pvof == -1 and qvof == -1:
        for i in range(0, 4, 1):
            if vnv[i] == 1 and vn2v[i] == 1:
                Fin.append("V")
            if vnv[i] == 1 and vn2v[i] == -1:
                Fin.append("F")
            if vnv[i] == -1 and vn2v[i] == 1:
                Fin.append("V")
            if vnv[i] == -1 and vn2v[i] == -1:
                Fin.append("V")
def Bicondicionalidad():
    if pvof == 1 and qvof == 1:
        for i in range(0, 4, 1):
            if vn[i] == 1 and vn2[i] == 1:
                Fin.append("V")
            if vn[i] == 1 and vn2[i] == -1:
                Fin.append("F")
            if vn[i] == -1 and vn2[i] == 1:
                Fin.append("F")
            if vn[i] == -1 and vn2[i] == -1:
                Fin.append("V")
    if pvof == 1 and qvof == -1:
        for i in range(0, 4, 1):
            if vn[i] == 1 and vn2v[i] == 1:
                Fin.append("V")
            if vn[i] == 1 and vn2v[i] == -1:
                Fin.append("F")
            if vn[i] == -1 and vn2v[i] == 1:
                Fin.append("F")
            if vn[i] == -1 and vn2v[i] == -1:
                Fin.append("V")
    if pvof == -1 and qvof == 1:
        for i in range(0, 4, 1):
            if vnv[i] == 1 and vn2[i] == 1:
                Fin.append("V")
            if vnv[i] == 1 and vn2[i] == -1:
                Fin.append("F")
            if vnv[i] == -1 and vn2[i] == 1:
                Fin.append("F")
            if vnv[i] == -1 and vn2[i] == -1:
                Fin.append("V")
    if pvof == -1 and qvof == -1:
        for i in range(0, 4, 1):
            if vnv[i] == 1 and vn2v[i] == 1:
                Fin.append("V")
            if vnv[i] == 1 and vn2v[i] == -1:
                Fin.append("F")
            if vnv[i] == -1 and vn2v[i] == 1:
                Fin.append("F")
            if vnv[i] == -1 and vn2v[i] == -1:
                Fin.append("V")

#CONECTORES P2
def disyuncion2():
    pvof = pvof2
    qvof = qvof2
    if pvof == 1 and qvof == 1:
        for i in range(0, 4, 1):
            if vn[i] == 1 and vn2[i] == 1:
                Fin2.append("V")
            if vn[i] == 1 and vn2[i] == -1:
                Fin2.append("V")
            if vn[i] == -1 and vn2[i] == 1:
                Fin2.append("V")
            if vn[i] == -1 and vn2[i] == -1:
                Fin2.append("F")
    if pvof == 1 and qvof == -1:
        for i in range(0, 4, 1):
            if vn[i] == 1 and vn2v[i] == 1:
                Fin2.append("V")
            if vn[i] == 1 and vn2v[i] == -1:
                Fin2.append("V")
            if vn[i] == -1 and vn2v[i] == 1:
                Fin2.append("V")
            if vn[i] == -1 and vn2v[i] == -1:
                Fin2.append("F")
    if pvof == -1 and qvof == 1:
        for i in range(0, 4, 1):
            if vnv[i] == 1 and vn2[i] == 1:
                Fin2.append("V")
            if vnv[i] == 1 and vn2[i] == -1:
                Fin2.append("V")
            if vnv[i] == -1 and vn2[i] == 1:
                Fin2.append("V")
            if vnv[i] == -1 and vn2[i] == -1:
                Fin2.append("F")
    if pvof == -1 and qvof == -1:
        for i in range(0, 4, 1):
            if vnv[i] == 1 and vn2v[i] == 1:
                Fin2.append("V")
            if vnv[i] == 1 and vn2v[i] == -1:
                Fin2.append("V")
            if vnv[i] == -1 and vn2v[i] == 1:
                Fin2.append("V")
            if vnv[i] == -1 and vn2v[i] == -1:
                Fin2.append("F")
def conjuncion2():
    pvof = pvof2
    qvof = qvof2
    if pvof == 1 and qvof == 1:
        for i in range(0, 4, 1):
            if vn[i] == 1 and vn2[i] == 1:
                Fin2.append("V")
            if vn[i] == 1 and vn2[i] == -1:
                Fin2.append("F")
            if vn[i] == -1 and vn2[i] == 1:
                Fin2.append("F")
            if vn[i] == -1 and vn2[i] == -1:
                Fin2.append("F")
    if pvof == 1 and qvof == -1:
        for i in range(0, 4, 1):
            if vn[i] == 1 and vn2v[i] == 1:
                Fin2.append("V")
            if vn[i] == 1 and vn2v[i] == -1:
                Fin2.append("F")
            if vn[i] == -1 and vn2v[i] == 1:
                Fin2.append("F")
            if vn[i] == -1 and vn2v[i] == -1:
                Fin2.append("F")
    if pvof == -1 and qvof == 1:
        for i in range(0, 4, 1):
            if vnv[i] == 1 and vn2[i] == 1:
                Fin2.append("V")
            if vnv[i] == 1 and vn2[i] == -1:
                Fin2.append("F")
            if vnv[i] == -1 and vn2[i] == 1:
                Fin2.append("F")
            if vnv[i] == -1 and vn2[i] == -1:
                Fin2.append("F")
    if pvof == -1 and qvof == -1:
        for i in range(0, 4, 1):
            if vnv[i] == 1 and vn2v[i] == 1:
                Fin2.append("V")
            if vnv[i] == 1 and vn2v[i] == -1:
                Fin2.append("F")
            if vnv[i] == -1 and vn2v[i] == 1:
                Fin2.append("F")
            if vnv[i] == -1 and vn2v[i] == -1:
                Fin2.append("F")
def Condicionalidad2():
    pvof = pvof2
    qvof = qvof2
    if pvof == 1 and qvof == 1:
        for i in range(0, 4, 1):
            if vn[i] == 1 and vn2[i] == 1:
                Fin2.append("V")
            if vn[i] == 1 and vn2[i] == -1:
                Fin2.append("F")
            if vn[i] == -1 and vn2[i] == 1:
                Fin2.append("V")
            if vn[i] == -1 and vn2[i] == -1:
                Fin2.append("V")
    if pvof == 1 and qvof == -1:
        for i in range(0, 4, 1):
            if vn[i] == 1 and vn2v[i] == 1:
                Fin2.append("V")
            if vn[i] == 1 and vn2v[i] == -1:
                Fin2.append("F")
            if vn[i] == -1 and vn2v[i] == 1:
                Fin2.append("V")
            if vn[i] == -1 and vn2v[i] == -1:
                Fin2.append("V")
    if pvof == -1 and qvof == 1:
        for i in range(0, 4, 1):
            if vnv[i] == 1 and vn2[i] == 1:
                Fin2.append("V")
            if vnv[i] == 1 and vn2[i] == -1:
                Fin2.append("F")
            if vnv[i] == -1 and vn2[i] == 1:
                Fin2.append("V")
            if vnv[i] == -1 and vn2[i] == -1:
                Fin2.append("V")
    if pvof == -1 and qvof == -1:
        for i in range(0, 4, 1):
            if vnv[i] == 1 and vn2v[i] == 1:
                Fin2.append("V")
            if vnv[i] == 1 and vn2v[i] == -1:
                Fin2.append("F")
            if vnv[i] == -1 and vn2v[i] == 1:
                Fin2.append("V")
            if vnv[i] == -1 and vn2v[i] == -1:
                Fin2.append("V")
def Bicondicionalidad2():
    pvof = pvof2
    qvof = qvof2
    if pvof == 1 and qvof == 1:
        for i in range(0, 4, 1):
            if vn[i] == 1 and vn2[i] == 1:
                Fin2.append("V")
            if vn[i] == 1 and vn2[i] == -1:
                Fin2.append("F")
            if vn[i] == -1 and vn2[i] == 1:
                Fin2.append("F")
            if vn[i] == -1 and vn2[i] == -1:
                Fin2.append("V")
    if pvof == 1 and qvof == -1:
        for i in range(0, 4, 1):
            if vn[i] == 1 and vn2v[i] == 1:
                Fin2.append("V")
            if vn[i] == 1 and vn2v[i] == -1:
                Fin2.append("F")
            if vn[i] == -1 and vn2v[i] == 1:
                Fin2.append("F")
            if vn[i] == -1 and vn2v[i] == -1:
                Fin2.append("V")
    if pvof == -1 and qvof == 1:
        for i in range(0, 4, 1):
            if vnv[i] == 1 and vn2[i] == 1:
                Fin2.append("V")
            if vnv[i] == 1 and vn2[i] == -1:
                Fin2.append("F")
            if vnv[i] == -1 and vn2[i] == 1:
                Fin2.append("F")
            if vnv[i] == -1 and vn2[i] == -1:
                Fin2.append("V")
    if pvof == -1 and qvof == -1:
        for i in range(0, 4, 1):
            if vnv[i] == 1 and vn2v[i] == 1:
                Fin2.append("V")
            if vnv[i] == 1 and vn2v[i] == -1:
                Fin2.append("F")
            if vnv[i] == -1 and vn2v[i] == 1:
                Fin2.append("F")
            if vnv[i] == -1 and vn2v[i] == -1:
                Fin2.append("V")

#PARA FUNCIÓN DE P O Q EN CONCLUSIÓN
def pc():
    pvof = pvof3
    if pvof == 1 :
        for i in range(0,4,1):
            if vn[0] == 1 :
                Fin3.append("V")
            if vn[1] == 1  :
                Fin3.append("V")
            if vn[2] == -1  :
                Fin3.append("F")
            if vn[3] == -1 :
                Fin3.append("F")
def np():
    pvof = pvof3
    if pvof == -1 :
        for i in range(0,4,1):
            if vnv[0] == -1 :
                Fin3.append("F")
            if vnv[1] == -1 :
                Fin3.append("F")
            if vnv[2] == 1 :
                Fin3.append("V")
            if vnv[3] == 1 :
                Fin3.append("V")
def qc():
    qvof = qvof3
    if  qvof == 1:
        for i in range(0,4,1):
            if  vn2[0] == 1:
                Fin3.append("V")
            if  vn2[1] == -1:
                Fin3.append("F")
            if  vn2[2] == 1:
                Fin3.append("V")
            if  vn2[3] == -1:
                Fin3.append("F")
def nq():
    qvof = qvof3
    if  qvof == -1:
        for i in range(0,4,1):
            if vn2v[0] == -1:
                Fin3.append("F")
            if vn2v[1] == 1:
                Fin3.append("V")
            if  vn2v[2] == -1:
                Fin3.append("F")
            if  vn2v[3] == 1:
                Fin3.append("V")

#CONECTORES CN
def disyuncion3():

    pvof = pvof3
    qvof = qvof3
    if pvof == 1 and qvof == 1:
        for i in range(0,4,1):
            if vn[i] == 1 and vn2[i] == 1:
                Fin3.append("V")
            if vn[i] == 1 and vn2[i] == -1:
                Fin3.append("V")
            if vn[i] == -1 and vn2[i] == 1:
                Fin3.append("V")
            if vn[i] == -1 and vn2[i] == -1:
                Fin3.append("F")
    if pvof == 1 and qvof == -1:
        for i in range(0,4,1):
            if vn[i] == 1 and vn2v[i] == 1:
                Fin3.append("V")
            if vn[i] == 1 and vn2v[i] == -1:
                Fin3.append("V")
            if vn[i] == -1 and vn2v[i]  == 1:
                Fin3.append("V")
            if vn[i] == -1 and vn2v[i] == -1:
                Fin3.append("F")
    if pvof == -1 and qvof == 1:
        for i in range(0,4,1):
            if vnv[i] == 1 and vn2[i] == 1:
                Fin3.append("V")
            if vnv[i] == 1 and vn2[i] == -1:
                Fin3.append("V")
            if vnv[i] == -1 and vn2[i] == 1:
                Fin3.append("V")
            if vnv[i] == -1 and vn2[i] == -1:
                Fin3.append("F")
    if pvof == -1 and qvof == -1:
        for i in range(0,4,1):
            if vnv[i] == 1 and vn2v[i] == 1:
                Fin3.append("V")
            if vnv[i] == 1 and vn2v[i] == -1:
                Fin3.append("V")
            if vnv[i] == -1 and vn2v[i] == 1:
                Fin3.append("V")
            if vnv[i] == -1 and vn2v[i] == -1:
                Fin3.append("F")
def conjuncion3():
    pvof = pvof3
    qvof = qvof3
    if pvof == 1 and qvof == 1:
        for i in range(0,4,1):
            if vn[i] == 1 and vn2[i] == 1:
                Fin3.append("V")
            if vn[i] == 1 and vn2[i] == -1:
                Fin3.append("F")
            if vn[i] == -1 and vn2[i] == 1:
                Fin3.append("F")
            if vn[i] == -1 and vn2[i] == -1:
                Fin3.append("F")
    if pvof == 1 and qvof == -1:
        for i in range(0,4,1):
            if vn[i] == 1 and vn2v[i] == 1:
                Fin3.append("V")
            if vn[i] == 1 and vn2v[i] == -1:
                Fin3.append("F")
            if vn[i] == -1 and vn2v[i]  == 1:
                Fin3.append("F")
            if vn[i] == -1 and vn2v[i] == -1:
                Fin3.append("F")
    if pvof == -1 and qvof == 1:
        for i in range(0,4,1):
            if vnv[i] == 1 and vn2[i] == 1:
                Fin3.append("V")
            if vnv[i] == 1 and vn2[i] == -1:
                Fin3.append("F")
            if vnv[i] == -1 and vn2[i] == 1:
                Fin3.append("F")
            if vnv[i] == -1 and vn2[i] == -1:
                Fin3.append("F")
    if pvof == -1 and qvof == -1:
        for i in range(0,4,1):
            if vnv[i] == 1 and vn2v[i] == 1:
                Fin3.append("V")
            if vnv[i] == 1 and vn2v[i] == -1:
                Fin3.append("F")
            if vnv[i] == -1 and vn2v[i] == 1:
                Fin3.append("F")
            if vnv[i] == -1 and vn2v[i] == -1:
                Fin3.append("F")
def Condicionalidad3():
    pvof = pvof3
    qvof = qvof3
    if pvof == 1 and qvof == 1:
        for i in range(0,4,1):
            if vn[i] == 1 and vn2[i] == 1:
                Fin3.append("V")
            if vn[i] == 1 and vn2[i] == -1:
                Fin3.append("F")
            if vn[i] == -1 and vn2[i] == 1:
                Fin3.append("V")
            if vn[i] == -1 and vn2[i] == -1:
                Fin3.append("V")
    if pvof == 1 and qvof == -1:
        for i in range(0,4,1):
            if vn[i] == 1 and vn2v[i] == 1:
                Fin3.append("V")
            if vn[i] == 1 and vn2v[i] == -1:
                Fin3.append("F")
            if vn[i] == -1 and vn2v[i]  == 1:
                Fin3.append("V")
            if vn[i] == -1 and vn2v[i] == -1:
                Fin3.append("V")
    if pvof == -1 and qvof == 1:
        for i in range(0,4,1):
            if vnv[i] == 1 and vn2[i] == 1:
                Fin3.append("V")
            if vnv[i] == 1 and vn2[i] == -1:
                Fin3.append("F")
            if vnv[i] == -1 and vn2[i] == 1:
                Fin3.append("V")
            if vnv[i] == -1 and vn2[i] == -1:
                Fin3.append("V")
    if pvof == -1 and qvof == -1:
        for i in range(0,4,1):
            if vnv[i] == 1 and vn2v[i] == 1:
                Fin3.append("V")
            if vnv[i] == 1 and vn2v[i] == -1:
                Fin3.append("F")
            if vnv[i] == -1 and vn2v[i] == 1:
                Fin3.append("V")
            if vnv[i] == -1 and vn2v[i] == -1:
                Fin3.append("V")
def Bicondicionalidad3():
    pvof = pvof3
    qvof = qvof3
    if pvof == 1 and qvof == 1:
        for i in range(0,4,1):
            if vn[i] == 1 and vn2[i] == 1:
                Fin3.append("V")
            if vn[i] == 1 and vn2[i] == -1:
                Fin3.append("F")
            if vn[i] == -1 and vn2[i] == 1:
                Fin3.append("F")
            if vn[i] == -1 and vn2[i] == -1:
                Fin3.append("V")
    if pvof == 1 and qvof == -1:
        for i in range(0,4,1):
            if vn[i] == 1 and vn2v[i] == 1:
                Fin3.append("V")
            if vn[i] == 1 and vn2v[i] == -1:
                Fin3.append("F")
            if vn[i] == -1 and vn2v[i]  == 1:
                Fin3.append("F")
            if vn[i] == -1 and vn2v[i] == -1:
                Fin3.append("V")
    if pvof == -1 and qvof == 1:
        for i in range(0,4,1):
            if vnv[i] == 1 and vn2[i] == 1:
                Fin3.append("V")
            if vnv[i] == 1 and vn2[i] == -1:
                Fin3.append("F")
            if vnv[i] == -1 and vn2[i] == 1:
                Fin3.append("F")
            if vnv[i] == -1 and vn2[i] == -1:
                Fin3.append("V")
    if pvof == -1 and qvof == -1:
        for i in range(0,4,1):
            if vnv[i] == 1 and vn2v[i] == 1:
                Fin3.append("V")
            if vnv[i] == 1 and vn2v[i] == -1:
                Fin3.append("F")
            if vnv[i] == -1 and vn2v[i] == 1:
                Fin3.append("F")
            if vnv[i] == -1 and vn2v[i] == -1:
                Fin3.append("V")



#PRIMERA PREMISA
print(50*"-")
print("Ingrese la primer premisa")
print("Ingrese p y q seprandolos con un enter")
print(50*"-")

print("En lenguaje natural:")
p1 = str(input("P1: "))
pvof = int(1)
print(pvof)

nega = str(input("¿Quieres negar la premisa?: (SI/NO) ")).upper()

while nega != "SI":
  if nega == "NO" or nega == "NEL":
    break
  nega = str(input("¿Quieres negar la premisa?: (SI/NO) ")).upper()

if nega == "SI" or nega == "SIMON":
  pvof = int(-1 * int(pvof))
print(pvof)
print(50*"-")


print("En lenguaje natural:")
q = str(input("Q1: "))
qvof = int(1)
print(qvof)

nega2 = str(input("¿Quieres negar la premisa?: (SI/NO) ")).upper()

while nega2 != "SI":
  if nega2 == "NO" or nega2 == "NEL":
    break
  nega2 = str(input("¿Quieres negar la premisa?: (SI/NO) ")).upper()

if nega2 == "SI":
  qvof = int(-1 * int(qvof))
print(qvof)
print(50*"-")

print("Conector lógico:")
print("1.- V")
print("2.- ∧ ")
print("3.- →")
print("4.- ↔")
print(50*"-")

cn = str(input("Ingrese el número del conector lógico que quiere usar: "))
print(50*"-")

if cn == "1":
  dip = pvof
  dip2 = qvof
  disyuncion()
  valor = ("p " + "V " + "q")

  if nega == "SI":
    valor = ("~p " + "V " + "q")

  elif nega2 == "SI":
    valor = ("p " + "V " + "~q")

  elif nega == "SI" and nega2 == "SI":
    valor = ("~p " + "V " + "~q")

  print(valor)
if cn == "2":
  dip = pvof
  dip2 = qvof
  conjuncion()
  valor1=("p " + "∧ " + "q")

  if nega == "SI":
    valor1 = ("~p " + "∧ " + "q")

  elif nega2 == "SI":
    valor1 = ("p " + "∧ " + "~q")

  elif nega == "SI" and nega2 == "SI":
    valor1 = ("~p " + "∧ " + "~q")

  print(valor1)
if cn == "3":
  dip = pvof
  dip2 = qvof
  Condicionalidad()
  valor2 = ("p " + "→ " + "q")

  if nega == "SI":
    valor2 = ("~p " + "→ " + "q")

  elif nega2 == "SI":
    valor2 = ("p " + "→ " + "~q")

  elif nega == "SI" and nega2 == "SI":
    valor2 = ("~p " + "→ " + "~q")

  print(valor2)
if cn == "4":
  dip = pvof
  dip2 = qvof
  Bicondicionalidad()
  valor3 = ("p " + "↔ " + "q")

  if nega == "SI":

    valor3 = ("~p " + "↔ " + "q")

  elif nega2 == "SI":
    valor3 = ("p " + "↔ " + "~q")

  elif nega == "SI" and nega2 == "SI":
    valor3 = ("~p " + "↔ " + "~q")

  print(valor3)


#SEGUNDA PREMISA
print(50*"-")
print("Ingrese la segunda premisa")
print("Ingrese p y q seprandolos con un enter")
print(50*"-")

print("En lenguaje natural:")
p2 = str(input("P2: "))
pvof2 = int(1)
print(pvof2)

nega = str(input("¿Quieres negar la premisa?: (SI/NO) ")).upper()

while nega != "SI":
  if nega == "NO" or nega == "NEL":
    break
  nega = str(input("¿Quieres negar la premisa?: (SI/NO) ")).upper()

if nega == "SI" or nega == "SIMON":
  pvof2 = int(-1 * int(pvof2))
print(pvof)
print(50*"-")


print("En lenguaje natural:")
q2 = str(input("Q2: "))
qvof2 = int(1)

print(qvof2)

nega2 = str(input("¿Quieres negar la premisa?: (SI/NO) ")).upper()

while nega2 != "SI":
  if nega2 == "NO" or nega2 == "NEL":
    break
  nega2 = str(input("¿Quieres negar la premisa?: (SI/NO) ")).upper()

if nega2 == "SI":
  qvof2 = int(-1 * int(qvof2))
print(qvof2)
print(50*"-")

print("Conector lógico:")
print("1.- V")
print("2.- ∧ ")
print("3.- →")
print("4.- ↔")
print(50*"-")

cn2 = str(input("Ingrese el número del conector lógico que quiere usar: "))
print(50*"-")


if cn2 == "1":
  disyuncion2()
  valor = ("p " + "V " + "q")

  if nega == "SI":
    valor = ("~p " + "V " + "q")

  elif nega2 == "SI":
    valor = ("p " + "V " + "~q")

  elif nega == "SI" and nega2 == "SI":
    valor = ("~p " + "V " + "~q")

  print(valor)
if cn2 == "2":
  conjuncion2()
  valor1=("p " + "∧ " + "q")

  if nega == "SI":
    valor1 = ("~p " + "∧ " + "q")

  elif nega2 == "SI":
    valor1 = ("p " + "∧ " + "~q")

  elif nega == "SI" and nega2 == "SI":
    valor1 = ("~p " + "∧ " + "~q")

  print(valor1)
if cn2 == "3":
  Condicionalidad2()
  valor2 = ("p " + "→ " + "q")

  if nega == "SI":
    valor2 = ("~p " + "→ " + "q")

  elif nega2 == "SI":
    valor2 = ("p " + "→ " + "~q")

  elif nega == "SI" and nega2 == "SI":
    valor2 = ("~p " + "→ " + "~q")

  print(valor2)
if cn2 == "4":
  Bicondicionalidad2()
  valor3 = ("p " + "↔ " + "q")

  if nega == "SI":

    valor3 = ("~p " + "↔ " + "q")

  elif nega2 == "SI":
    valor3 = ("p " + "↔ " + "~q")

  elif nega == "SI" and nega2 == "SI":
    valor3 = ("~p " + "↔ " + "~q")

  print(valor3)

#CONCLUSIÓN
print(50*"-")
print("Ingrese la conclusión")
print("Ingrese (p) ó (q) ó (p y q)  seprandolos con un enter")
print(50*"-")
print("1. P")
print("2. Q")
print("3. P y Q")

print(50*"-")

compr = int(input("¿Qué desea ingresar como conclusión? (1/2/3): "))


#PREMISA P
if compr == 1:
    cn3 = 0
    print("En lenguaje natural:")
    p1 = str(input("PC: "))
    pvof3 = 1
    print(pvof3)

    nega = str(input("¿Quieres negar la premisa?: (SI/NO) ")).upper()

    while nega != "SI":
        if nega == "NO" or nega == "NEL":
            break
        nega = str(input("¿Quieres negar la premisa?: (SI/NO) ")).upper()

    if nega == "SI" or nega == "SIMON":
        pvof3 = pvof3 * -1
        print("~p")
        Fin3 = f1v
    else:
        print("p")
        Fin3 = f1
    print(pvof3)





    print(50 * "-")


#PREMISA Q
if compr  == 2:
    cn3 = 0
    print("En lenguaje natural:")
    q = str(input("QC: "))
    qvof3 = int(1)
    print(qvof3)

    nega2 = str(input("¿Quieres negar la premisa?: (SI/NO) ")).upper()

    while nega2 != "SI":
        if nega2 == "NO" or nega2 == "NEL":
            break
        nega2 = str(input("¿Quieres negar la premisa?: (SI/NO) ")).upper()

    if nega2 == "SI":
        qvof3 = qvof3 * -1
        Fin3 = f2v
        print("~q")
    else:
        print("q")
        Fin3 = f2
    print(qvof3)
    print(50 * "-")


#Premisa P y Q
if compr == 3:
#Aqui corre P
    print("En lenguaje natural:")
    p1 = str(input("PC: "))
    pvof3 = 1
    print(pvof3)

    nega = str(input("¿Quieres negar la premisa?: (SI/NO) ")).upper()

    while nega != "SI":
        if nega == "NO" or nega == "NEL":
            break
        nega = str(input("¿Quieres negar la premisa?: (SI/NO) ")).upper()

    if nega == "SI" or nega == "SIMON":
        pvof3 = pvof3 * -1
    print(pvof3)
    print(50 * "-")

#Aqui empieza Q
    print("En lenguaje natural:")
    q = str(input("QC: "))
    qvof3 = int(1)
    print(qvof3)

    nega2 = str(input("¿Quieres negar la premisa?: (SI/NO) ")).upper()

    while nega2 != "SI":
        if nega2 == "NO" or nega2 == "NEL":
            break
        nega2 = str(input("¿Quieres negar la premisa?: (SI/NO) ")).upper()

    if nega2 == "SI":
        qvof3 = qvof3 * -1
    print(qvof3)
    print(50 * "-")

    print("Conector lógico:")
    print("1.- V")
    print("2.- ∧ ")
    print("3.- →")
    print("4.- ↔")
    print(50 * "-")

    cn3 = str(input("Ingrese el número del conector lógico que quiere usar: "))
    print(50 * "-")

if cn3 == "1":

  disyuncion3()
  valor = ("p " + "V " + "q")

  if nega == "SI":
    valor = ("~p " + "V " + "q")

  elif nega2 == "SI":
    valor = ("p " + "V " + "~q")

  elif nega == "SI" and nega2 == "SI":
    valor = ("~p " + "V " + "~q")

  print(valor)
if cn3 == "2":

  conjuncion3()
  valor1=("p " + "∧ " + "q")

  if nega == "SI":
    valor1 = ("~p " + "∧ " + "q")

  elif nega2 == "SI":
    valor1 = ("p " + "∧ " + "~q")

  elif nega == "SI" and nega2 == "SI":
    valor1 = ("~p " + "∧ " + "~q")

  print(valor1)
if cn3 == "3":

  Condicionalidad3()
  valor2 = ("p " + "→ " + "q")

  if nega == "SI":
    valor2 = ("~p " + "→ " + "q")

  elif nega2 == "SI":
    valor2 = ("p " + "→ " + "~q")

  elif nega == "SI" and nega2 == "SI":
    valor2 = ("~p " + "→ " + "~q")

  print(valor2)
if cn3 == "4":

  Bicondicionalidad3()
  valor3 = ("p " + "↔ " + "q")

  if nega == "SI":

    valor3 = ("~p " + "↔ " + "q")

  elif nega2 == "SI":
    valor3 = ("p " + "↔ " + "~q")

  elif nega == "SI" and nega2 == "SI":
    valor3 = ("~p " + "↔ " + "~q")

  print(valor3)

print(50*"-")
print("Tabla de Verdad")
print(50*"-")
#TABLAS DE VERDAD

A1 = pd.DataFrame({
    "P": [f1[0], f1[1], f1[2], f1[3]],
    "Q": [f2[0], f2[1], f2[2], f2[3]],
    "P1": [Fin[0], Fin[1], Fin[2], Fin[3]],
    "P2": [Fin2[0], Fin2[1], Fin2[2], Fin2[3]],
    "C": [Fin3[0], Fin3[1], Fin3[2], Fin3[3]]

})

A2 = pd.DataFrame({
    "P":[f1[0], f1[1], f1[2], f1[3]],
    "Q":[f2[0], f2[1], f2[2], f2[3]],
    "~Q":[f2v[0], f2v[1], f2v[2], f2v[3]],
    "P1":[Fin[0], Fin[1], Fin[2], Fin[3]],
    "P2":[Fin2[0], Fin2[1], Fin2[2], Fin2[3]],
    "C": [Fin3[0], Fin3[1], Fin3[2], Fin3[3]]
})

A3 = pd.DataFrame({
    "P":[f1[0], f1[1], f1[2], f1[3]],
    "Q":[f2[0], f2[1], f2[2], f2[3]],
    "~P":[f1v[0], f1v[1], f1v[2], f1v[3]],
    "P1": [Fin[0], Fin[1], Fin[2], Fin[3]],
    "P2": [Fin2[0], Fin2[1], Fin2[2], Fin2[3]],
    "C": [Fin3[0], Fin3[1], Fin3[2], Fin3[3]]

})

A4 = pd.DataFrame({
    "P":[f1[0], f1[1], f1[2], f1[3]],
    "Q":[f2[0], f2[1], f2[2], f2[3]],
    "~P":[f1v[0], f1v[1], f1v[2], f1v[3]],
    "~Q":[f2v[0], f2v[1], f2v[2], f2v[3]],
    "P1":[Fin[0], Fin[1], Fin[2], Fin[3]],
    "P2":[Fin2[0], Fin2[1], Fin2[2], Fin2[3]],
    "C": [Fin3[0], Fin3[1], Fin3[2], Fin3[3]]
})

if dip == -1 or pvof2 == -1 or pvof3 == -1:
    if dip2 == -1 or qvof2 == -1 or qvof3 == -1:
        print(A4)
    else:
        print(A3)
elif dip2 == -1 or qvof2 == -1 or qvof3 == -1:
    print(A2)
else:
    print(A1)

#Renglones críticos
crit = int(1)
if Fin[0] == "V" :
    if Fin2[0] == "V" :
        if Fin3[0] == "V" :
            crit = int(1)
        elif Fin3[0] == "F" :
            crit = int(-1)
else:
    pass

crit1 = int(1)
if Fin[1] == "V" :
    if Fin2[1] == "V" :
        if Fin3[1] == "V" :
            crit1 = int(1)
        elif Fin3[1] == "F" :
            crit1 = int(-1)
else:
    pass

crit2 = int(1)
if Fin[2] == "V" :
    if Fin2[2] == "V" :
        if Fin3[2] == "V" :
            crit2 = int(1)
        elif Fin3[2] == "F" :
            crit2 = int(-1)
else:
    pass

crit3 = int(1)
if Fin[3] == "V" :
    if Fin2[3] == "V" :
        if Fin3[3] == "V" :
            crit3 = int(1)
        elif Fin3[3] == "F" :
            crit3 = int(-1)
else:
    pass


print(50*"-")
if crit == -1 or crit1 == -1 or crit2 == -1 or crit3 == -1:
    print("Su argumento no es válido")
elif crit == 1 and crit1 == 1 and crit2 == 1 and crit3 == 1:
    print("Su argumento es válido")

print(50*"-")
print("")
print(50*"~")
print(8*"~", "Gracias por usar nuestro programa", 7*"~")
print(50*"~")
print(22*"~", "Atte.:", 20*"~")
print(50*"~")
print(22*"~", "Chris", 21*"~")
print(22*"~", "Said", 22*"~")
print(22*"~", "Diego", 21*"~")
print(50*"~")

