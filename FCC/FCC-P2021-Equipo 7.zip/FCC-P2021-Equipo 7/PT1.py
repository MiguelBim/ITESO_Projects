#Christian Alejandro Pereda González
#Said Gabriel Santana García
#Diego Solórzano Castañeda

print(50*"-")
print("Ingrese p y q seprandolos con un enter") 
print(50*"-")

p = str(input("P: "))
pvof = str(input("¿Su premisa es verdadera o falsa?: (V/F)")).upper()


while pvof != "V" :
    if pvof == "F":
        break
    pvof = str(input("¿Su premisa es verdadera o falsa?: (V/F)")).upper()

if pvof == "V":
    pvof = 1
if pvof == "F":
    pvof = -1
   
print(pvof)

nega = str(input("¿Quieres negar la premisa?: (SI/NO) ")).upper()

while nega != "SI":
  if nega == "NO" or nega == "NEL":
    break
  nega = str(input("¿Quieres negar la premisa?: (SI/NO) ")).upper()

if nega == "SI" or nega == "SIMON":
  pvof = -1 * int(pvof)
print(pvof)
print(50*"-")


  
q = str(input("Q: "))
qvof = str(input("¿Su premisa es verdadera o falsa?: (V/F)")).upper()


while qvof != "V" :
    if qvof == "F":
        break
    qvof = str(input("¿Su premisa es verdadera o falsa?: (V/F)")).upper()

if qvof == "V":
    qvof = 1
if qvof == "F":
    qvof = -1
   
print(qvof)

nega2 = str(input("¿Quieres negar la premisa?: (SI/NO) ")).upper()

while nega2 != "SI":
  if nega2 == "NO" or nega2 == "NEL":
    break
  nega2 = str(input("¿Quieres negar la premisa?: (SI/NO) ")).upper()

if nega2 == "SI":
  qvof = -1 * int(qvof)
print(qvof) 
print(50*"-")

print("Conector lógico:")
print("1.- V")
print("2.- ∧ ")
print("3.- →")
print("4.- ↔")
print(50*"-")

cn = str(input("Ingrese el número del conector lógico que quiere usar: "))
print(50*"-")


if cn == "1":

  valor = ("p " + "V " + "q")
  
  if nega == "SI":
    valor = ("~p " + "V " + "q")
    
  elif nega2 == "SI":
    valor = ("p " + "V " + "~q")

  elif nega == "SI" and nega2 == "SI":
    valor = ("~p " + "V " + "~q")

  print(valor)
  
  if pvof == 1 and qvof == 1:
    print(valor," es verdadero") 
    
  elif pvof == 1 and qvof == -1:
    print(valor," es verdadero")
  
  elif pvof == -1 and qvof == 1:
    print(valor," es verdadero") 

  elif pvof == -1 and qvof == -1:
    print(valor," es falso")   


if cn == "2":
  
  valor1=("p " + "∧  " + "q")
  
  if nega == "SI":
    valor1 = ("~p " + "∧  " + "q")
    
  elif nega2 == "SI":
    valor1 = ("p " + "∧  " + "~q")

  elif nega == "SI" and nega2 == "SI":
    valor1 = ("~p " + "∧  " + "~q")

  print(valor1)
  
  if pvof == 1 and qvof == 1:
    print(valor1," es verdadero") 
    
  elif pvof == 1 and qvof == -1:
    print(valor1," es falso")
  
  elif pvof == -1 and qvof == 1:
    print(valor1," es falso") 

  elif pvof == -1 and qvof == -1:
    print(valor1," es falso")   
  
if cn == "3":
  
  valor2 = ("p " + "→ " + "q")
  
  if nega == "SI":
    valor2 = ("~p " + "→ " + "q")
    
  elif nega2 == "SI":
    valor2 = ("p " + "→ " + "~q")

  elif nega == "SI" and nega2 == "SI":
    valor2 = ("~p " + "→ " + "~q")

  print(valor2)

  if pvof == 1 and qvof == 1:
    print(valor2," es verdadero") 
    
  elif pvof == 1 and qvof == -1:
    print(valor2," es falso")
  
  elif pvof == -1 and qvof == 1:
    print(valor2," es verdadero") 

  elif pvof == -1 and qvof == -1:
    print(valor2," es verdadero")   



if cn == "4":

  valor3 = ("p " + "↔ " + "q")
  
  if nega == "SI":

    valor3 = ("~p " + "↔ " + "q")
    
  elif nega2 == "SI":
    valor3 = ("p " + "↔ " + "~q")

  elif nega == "SI" and nega2 == "SI":
    valor3 = ("~p " + "↔ " + "~q")

  print(valor3)

  if pvof == 1 and qvof == 1:
    print(valor3," es verdadero") 
    
  elif pvof == 1 and qvof == -1:
    print(valor3," es falso")
  
  elif pvof == -1 and qvof == 1:
    print(valor3," es falso") 

  elif pvof == -1 and qvof == -1:
    print(valor3," es verdadero") 
  


   
