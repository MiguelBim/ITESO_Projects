def conjuncion(diccionario,simblist):
    result = True
    for i in range(len(diccionario)):
        result = result and diccionario[simblist[i]][1]        
    return result

def disyuncionI(diccionario,simblist):
    result = False
    for i in range(len(diccionario)):
        result = result or diccionario[simblist[i]][1]
    return result

def disyuncionE(diccionario,simblist):
    result = False
    for i in range(len(diccionario)):
        result = (result or diccionario[simblist[i]][1]) and not(result and diccionario[simblist[i]][1])
    return result

def condicional(diccionario,simblist):
    result = True
    for i in range(len(diccionario)):
        result = not(result) or diccionario[simblist[i]][1]
    return result

def bicondicional(diccionario,simblist):
    result = True
    for i in range(len(diccionario)):
        result = ((not(result) or diccionario[simblist[i]][1]) and (not(diccionario[simblist[i]][1]) or result))
    return result

def negacion(diccionario,simblist):
    for i in range(len(diccionario)):
        print("~"+simblist[1]+"= ",end="")
        print("F" if not(diccionario[simblist[i]][1]) == False else "V")

def imprimir(diccionario,simblist,signo,nombrefun,result):
    result ="Falso" if result == False else "Verdadero"
    for i in range(len(diccionario)):
        print(simblist[i], end="") if i== len(diccionario)-1 else print(simblist[i], f"{signo} ", end="")                
    print(" =", "V" if result=="Verdadero" else "F")
    print(f"El resultado de la {nombrefun} es",result)

diccionario = {}
listSimb = []
num_variables = int(input("Cuántas premisas serán ingresadas? "))
for i in range(1,num_variables+1):
    proposicion = input(f"Ingrese la proposicion numero {i}: ")
    valor = int(input(f"Ingrese el valor de la proposicion numero {i} (1 para verdadero y 0 para falso): "))
    simb = input(f"Ingresa el simbolo de la premisa {i}: ")
    listSimb.append(simb)
    valor = False if valor == 0 else True
    diccionario[simb] = [proposicion, valor]
    
print()
print("Tus proposiciones son: ")
for key, value in diccionario.items():
    val = "falso" if value[1] == False else "verdadero"
    print(f"{key}: '{value[0]}' con valor {val}")
print()

operacion = 0
while(operacion != 7):
    print("\nConjuncion = 1")
    print("Disyuncion inclusiva = 2")
    print("Disyuncion exclusiva = 3")
    print("Condicional = 4")
    print("Bicondicional = 5")
    print("Negacion = 6")
    print("Salir = 7")
    operacion = int(input("¿Que operación lógica desea realizar con sus proposiciones? "))

    if operacion == 1:
        result = conjuncion(diccionario,listSimb)
        imprimir(diccionario,listSimb,"∧","conjuncion",result)
    
    elif operacion == 2:
        result = disyuncionI(diccionario, listSimb)
        imprimir(diccionario,listSimb,"∨","disyunción inclusiva",result)
        
    elif operacion == 3:        
        result = disyuncionE(diccionario, listSimb)
        imprimir(diccionario,listSimb,"⨁","disyunción exclusiva",result)
        
    elif operacion == 4:
        result = condicional(diccionario, listSimb)
        imprimir(diccionario,listSimb,"→","condicional",result)
    
    elif operacion == 5:        
        result = bicondicional(diccionario, listSimb)
        imprimir(diccionario,listSimb,"↔","bicondicional",result)
    
    elif operacion == 6:
        negacion(diccionario, listSimb)

    elif operacion == 7:
        continue

    else:
        print("Opcion incorrecta")
