# proyecto fcc Disyuncion, conjuncion, condicional, bicondicional y negación

p = input("Escribe primer premisa: ")
valor1 = input("Tu premisa es V o F?: ")
# suponemos que el usuario responde 'V o F'

q = input("Escribe segunda premisa: ")
valor2 = input("Tu premisa es V o F?: ")
# suponemos que el usuario responde 'V o F'


if valor1 == "V" and valor2 == "V":
    signo = int(input("¿Qué conector quieres aplicar?"
                      " \n 1) Conjunción \n 2) Disyunción \n 3) Condicional \n 4) Bicondicional \n 5) Negación \n"))
# suponemos que el usuario responde números del 1 al 5
    if signo == 5:
        print("Premisa 1: FALSA \nPremisa 2: FALSA")
    elif signo > 0 and signo < 5:
        print(p, "y", q,  "EL VALOR ES VERDADERO")

elif valor1 == "V" and valor2 == "F":
    signo = int(input("¿Qué conector quieres aplicar?"
                      " \n 1) Conjunción \n 2) Disyunción \n 3) Condicional \n 4) Bicondicional \n 5) Negación \n"))
    if signo == 5:
            print("Premisa 1: FALSA \nPremisa 2: VERDADERA")
    elif signo == 2:
        print('EL VALOR ES VERDADERO')
    else:
        print('EL VALOR ES FALSO')

elif valor1 == "F" and valor2 == "V":
    signo = int(input("¿Qué conector quieres aplicar?"
                      " \n 1) Conjunción \n 2) Disyunción \n 3) Condicional \n 4) Bicondicional \n 5) Negación \n"))
    if signo == 5:
            print("Premisa 1: VERDADERA \nPremisa 2: FALSA")
    elif signo == 3 or signo == 2:
        print('EL VALOR ES VERDADERO')
    else:
        print("EL VALOR ES FALSO")

elif valor1 == "F" and valor2 == "F":
    signo = int(input("¿Qué conector quieres aplicar?"
                      " \n 1) Conjunción \n 2) Disyunción \n 3) Condicional \n 4) Bicondicional 5) Negación \n"))
    if signo == 5:
            print("Premisa 1: VERDADERA \nPremisa 2: VERDADERA")
    elif signo == 4 or signo == 3:
        print('EL VALOR ES VERDADERO')
    else:
        print('EL VALOR ES FALSO')



