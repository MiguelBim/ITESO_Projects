import itertools


while True:
    try:
        numero_de_proposiciones = int(input('Numero de proposiciones [1-5]: '))
        if numero_de_proposiciones < 1 or numero_de_proposiciones > 5:
            print('1 minimo 5 maximo')
        else:
            break
    except:
        ValueError
        print('Del 1 al 5:')

tabla_lista = list(itertools.product([True, False], repeat=numero_de_proposiciones))
premisa = input('Premisa a evaluar: [e.j.: (p and q) or (not r): ')
premisa2 = input('Segunda premisa a evaluar: [e.j.: (p and q) or (not r): ')
conclusion = input('Ingrese la conclusion: [e.j.: (p and q) or (not r): ')


print('--'*60)
print(f'P\t\t\tQ\t\t\tR\t\t\tS\t\t\tT\t{premisa}\t{premisa2}\t\t\tC: {conclusion}')
print('--'*60)
renglonescriticos = 2

for item in tabla_lista:
    posicion = 0
    if numero_de_proposiciones == 1:
        p = item[0]
    elif numero_de_proposiciones == 2:
        p,q = item[0], item[1]
    elif numero_de_proposiciones == 3:
        p,q,r = item[0], item[1], item[2]
    elif numero_de_proposiciones == 4:
        p,q,r,s = item[0], item[1], item[2], item[3]
    else:
        p,q,r,s,t = item[0], item[1], item[2], item[3], item[4]

    while posicion < numero_de_proposiciones:
        print(item[posicion], end = '\t\t')
        posicion += 1

    try:
        resultados = eval(premisa)
        resultados2 = eval(premisa2)
        resultadosc = eval(conclusion)
        print(f'\t\t\t\t\t{resultados}\t\t\t{resultados2}\t\t\t{resultadosc}')
        if resultados == True and resultados2 == True and resultadosc == False:
            renglonescriticos = 0
        elif resultados == True and resultados2 == True and resultadosc == True and renglonescriticos == 2:
            renglonescriticos = 1
    except:
        print('No se puede evaluar. Intenta de nuevo')


if renglonescriticos == 0:
    print("Argumento no válido.")
else:
    print("Argumento válido.")